import type {
  AuthUser,
  ScanHistoryItem,
  ScanReport,
  ScanStageId,
  ScanStageStatus,
  ScannerSettings,
} from '../types/scan';

async function jsonRequest<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
    ...init,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  getMe: () => jsonRequest<{ user: AuthUser | null; workspaceMode: 'account' | 'session' }>('/api/auth/me'),

  register: (payload: { name: string; email: string; password: string }) =>
    jsonRequest<{ user: AuthUser }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (payload: { email: string; password: string }) =>
    jsonRequest<{ user: AuthUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  logout: () =>
    jsonRequest<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),

  getSettings: () => jsonRequest<{ settings: ScannerSettings }>('/api/settings'),

  updateSettings: (settings: Partial<ScannerSettings>) =>
    jsonRequest<{ settings: ScannerSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  listScans: () => jsonRequest<{ scans: ScanHistoryItem[] }>('/api/scans'),

  getScan: (id: string) => jsonRequest<{ report: ScanReport }>(`/api/scans/${encodeURIComponent(id)}`),

  deleteScan: (id: string) =>
    jsonRequest<{ ok: boolean }>(`/api/scans/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  reanalyzeAI: (id: string) =>
    jsonRequest<{ report: ScanReport }>(`/api/scans/${encodeURIComponent(id)}/reanalyze-ai`, {
      method: 'POST',
    }),
};

export interface StreamCallbacks {
  onStage: (evt: {
    id: ScanStageId;
    status: ScanStageStatus;
    detail?: string;
    durationMs?: number;
  }) => void;
  onComplete: (report: ScanReport) => void;
  onError: (message: string) => void;
}

export async function runStreamingScan(
  url: string,
  authorized: boolean,
  callbacks: StreamCallbacks
): Promise<void> {
  const res = await fetch('/api/scans/stream', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url, authorized }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    callbacks.onError((errData as { error?: string }).error || `Scan request failed (${res.status}).`);
    return;
  }

  if (!res.body) {
    callbacks.onError('Streaming connection could not be established.');
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try {
        const parsed = JSON.parse(trimmed) as
          | {
              type: 'stage';
              id: ScanStageId;
              status: ScanStageStatus;
              detail?: string;
              durationMs?: number;
            }
          | { type: 'complete'; report: ScanReport }
          | { type: 'error'; error: string };

        if (parsed.type === 'stage') {
          callbacks.onStage({
            id: parsed.id,
            status: parsed.status,
            detail: parsed.detail,
            durationMs: parsed.durationMs,
          });
        } else if (parsed.type === 'complete') {
          callbacks.onComplete(parsed.report);
        } else if (parsed.type === 'error') {
          callbacks.onError(parsed.error);
        }
      } catch {
        // ignore partial JSON line
      }
    }
  }
}
