import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { ScanReport } from '../types/scan';

export function exportScanReportPdf(report: ScanReport): void {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 42;
  let cursorY = 48;

  const ensureSpace = (needed: number) => {
    const pageHeight = doc.internal.pageSize.getHeight();
    if (cursorY + needed > pageHeight - 48) {
      doc.addPage();
      cursorY = 48;
    }
  };

  // Header Banner
  doc.setFillColor(59, 36, 24);
  doc.rect(0, 0, pageWidth, 96, 'F');

  doc.setTextColor(242, 232, 218);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('LaunchGuard AI — Website Readiness Report', margin, 42);

  doc.setTextColor(142, 197, 255);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Build with AI. Test with AI. Launch with Confidence.', margin, 60);
  doc.setTextColor(216, 199, 180);
  doc.text(
    `Scanned: ${new Date(report.scannedAt).toLocaleString()}   |   Duration: ${(
      report.totalDurationMs / 1000
    ).toFixed(1)}s`,
    margin,
    78
  );

  cursorY = 122;

  // Target & Score Summary
  doc.setTextColor(59, 36, 24);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('Target Website', margin, cursorY);
  cursorY += 16;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(110, 80, 65);
  doc.text(`Requested URL: ${report.url}`, margin, cursorY);
  cursorY += 14;
  doc.text(`Final URL: ${report.finalUrl}`, margin, cursorY);
  cursorY += 14;
  doc.text(
    `HTTP Status: ${report.availability.statusCode} ${report.availability.statusText}   |   Response Time: ${report.availability.responseTimeMs} ms   |   HTTPS: ${report.availability.isHttps ? 'Yes' : 'No'}`,
    margin,
    cursorY
  );
  cursorY += 24;

  // Launch Readiness Scores Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(59, 36, 24);
  doc.text(
    `Overall Launch Readiness Score: ${report.score.overall} / 100 (${report.score.grade})`,
    margin,
    cursorY
  );
  cursorY += 10;

  autoTable(doc, {
    startY: cursorY,
    margin: { left: margin, right: margin },
    head: [['Category', 'Score', 'Weight', 'Status Summary']],
    body: [
      ['Security', `${report.score.categories.security} / 100`, '35%', `${report.security.findings.filter((f) => f.status === 'pass').length} passed, ${report.security.findings.filter((f) => f.status !== 'pass').length} issues`],
      ['Performance', `${report.score.categories.performance} / 100`, '25%', `${report.performance.responseTimeMs} ms · ${report.performance.htmlSizeKb} KB HTML`],
      ['SEO', `${report.score.categories.seo} / 100`, '20%', `${report.seo.title ? 'Title set' : 'No title'} · ${report.seo.metaDescription ? 'Meta desc set' : 'No meta desc'}`],
      ['Availability & Links', `${report.score.categories.availability} / 100`, '20%', `HTTP ${report.availability.statusCode} · ${report.links.brokenCount} broken link(s)`],
    ],
    styles: { fontSize: 9, cellPadding: 6, textColor: [59, 36, 24] },
    alternateRowStyles: { fillColor: [250, 245, 238] },
    headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
  });

  cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Security Findings & TLS
  ensureSpace(120);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(59, 36, 24);
  doc.text('Security Configuration Findings', margin, cursorY);
  cursorY += 14;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(110, 80, 65);
  const tlsLine = report.security.tls.available
    ? `TLS Certificate: ${report.security.tls.valid ? 'Valid' : 'Issue Detected'} | Issuer: ${report.security.tls.issuer ?? 'Unknown'} | Expires in: ${report.security.tls.daysRemaining ?? 'N/A'} days | Protocol: ${report.security.tls.protocol ?? 'N/A'}`
    : `TLS Certificate: Unavailable (${report.security.tls.error ?? 'Not HTTPS'})`;
  doc.text(doc.splitTextToSize(tlsLine, pageWidth - margin * 2), margin, cursorY);
  cursorY += 22;

  autoTable(doc, {
    startY: cursorY,
    margin: { left: margin, right: margin },
    head: [['Check', 'Severity', 'Observed', 'Recommendation']],
    body: report.security.findings.map((f) => [
      f.title,
      f.severity.toUpperCase(),
      f.observedValue,
      f.recommendation,
    ]),
    styles: { fontSize: 8.5, cellPadding: 5, overflow: 'linebreak' },
    headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
    columnStyles: { 0: { cellWidth: 120 }, 1: { cellWidth: 55 }, 2: { cellWidth: 120 } },
  });

  cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Performance & SEO Summary
  ensureSpace(130);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(59, 36, 24);
  doc.text('Performance & SEO Metrics', margin, cursorY);
  cursorY += 10;

  autoTable(doc, {
    startY: cursorY,
    margin: { left: margin, right: margin },
    head: [['Metric', 'Measured Value']],
    body: [
      ['Server Response Time', `${report.performance.responseTimeMs} ms`],
      ['HTML Document Size', `${report.performance.htmlSizeKb} KB (${report.performance.contentEncoding ?? 'uncompressed'})`],
      ['Images Found', `${report.performance.imageCount} (${report.performance.imagesWithoutLazyLoading} off-screen without lazy loading, ${report.seo.imagesMissingAlt} missing alt)`],
      ['External Scripts / Stylesheets', `${report.performance.externalScriptCount} scripts, ${report.performance.externalStylesheetCount} stylesheets`],
      ['Page Title', report.seo.title ? `${report.seo.title} (${report.seo.titleLength} chars)` : 'Missing'],
      ['Meta Description', report.seo.metaDescription ? `${report.seo.metaDescription} (${report.seo.metaDescriptionLength} chars)` : 'Missing'],
      ['H1 Heading Count', `${report.seo.h1Count}`],
      ['Internal Links Checked', `${report.links.checkedCount} checked · ${report.links.healthyCount} healthy · ${report.links.brokenCount} broken`],
    ],
    styles: { fontSize: 8.5, cellPadding: 5, textColor: [59, 36, 24] },
    alternateRowStyles: { fillColor: [250, 245, 238] },
    headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
    columnStyles: { 0: { cellWidth: 170 } },
  });

  cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Broken Links (if any)
  if (report.links.links.length > 0) {
    ensureSpace(100);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(59, 36, 24);
    doc.text('Internal Link Verification', margin, cursorY);
    cursorY += 10;

    autoTable(doc, {
      startY: cursorY,
      margin: { left: margin, right: margin },
      head: [['URL', 'Status', 'Latency']],
      body: report.links.links.map((l) => [
        l.url,
        l.statusCode ? `HTTP ${l.statusCode}` : l.error || 'Error',
        `${l.responseTimeMs} ms`,
      ]),
      styles: { fontSize: 8, cellPadding: 4, textColor: [59, 36, 24] },
      alternateRowStyles: { fillColor: [250, 245, 238] },
      headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
      columnStyles: { 1: { cellWidth: 90 }, 2: { cellWidth: 65 } },
    });

    cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;
  }

  // AI Recommendations & Launch Checklist
  if (report.ai.status === 'completed') {
    ensureSpace(140);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(59, 36, 24);
    doc.text('AI Website Analyst Recommendations', margin, cursorY);
    cursorY += 16;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(110, 80, 65);
    if (report.ai.executiveSummary) {
      const lines = doc.splitTextToSize(report.ai.executiveSummary, pageWidth - margin * 2);
      doc.text(lines, margin, cursorY);
      cursorY += lines.length * 13 + 10;
    }

    if (report.ai.prioritizedFixes && report.ai.prioritizedFixes.length > 0) {
      autoTable(doc, {
        startY: cursorY,
        margin: { left: margin, right: margin },
        head: [['Issue', 'Severity', 'Why It Matters', 'Fix Steps']],
        body: report.ai.prioritizedFixes.map((fix) => [
          fix.findingTitle,
          fix.severity.toUpperCase(),
          fix.whyItMatters,
          fix.stepByStepFix.map((s, i) => `${i + 1}. ${s}`).join('\n'),
        ]),
        styles: { fontSize: 8, cellPadding: 5, overflow: 'linebreak', textColor: [59, 36, 24] },
        alternateRowStyles: { fillColor: [250, 245, 238] },
        headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
        columnStyles: { 0: { cellWidth: 105 }, 1: { cellWidth: 50 }, 2: { cellWidth: 140 } },
      });
      cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 22;
    }

    if (report.ai.launchChecklist && report.ai.launchChecklist.length > 0) {
      ensureSpace(100);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(59, 36, 24);
      doc.text('Launch Checklist', margin, cursorY);
      cursorY += 10;

      autoTable(doc, {
        startY: cursorY,
        margin: { left: margin, right: margin },
        head: [['Status', 'Category', 'Priority', 'Checklist Item']],
        body: report.ai.launchChecklist.map((item) => [
          item.completed ? 'Done' : 'Open',
          item.category,
          item.priority,
          item.task,
        ]),
        styles: { fontSize: 8.5, cellPadding: 5, textColor: [59, 36, 24] },
        alternateRowStyles: { fillColor: [250, 245, 238] },
        headStyles: { fillColor: [59, 36, 24], textColor: [242, 232, 218] },
        columnStyles: { 0: { cellWidth: 45 }, 1: { cellWidth: 75 }, 2: { cellWidth: 85 } },
      });
      cursorY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 18;
    }
  }

  // Disclaimer footer on last page
  ensureSpace(40);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(125, 94, 78);
  doc.text(
    doc.splitTextToSize(report.security.scopeDisclaimer, pageWidth - margin * 2),
    margin,
    cursorY
  );

  const safeHost = (() => {
    try {
      return new URL(report.finalUrl).hostname.replace(/[^a-z0-9.-]/gi, '_');
    } catch {
      return 'website';
    }
  })();

  doc.save(`LaunchGuard-Report-${safeHost}-${new Date(report.scannedAt).toISOString().slice(0, 10)}.pdf`);
}
