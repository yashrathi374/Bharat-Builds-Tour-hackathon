import React, { useEffect, useState, useCallback } from 'react';
import {
  LayoutDashboard,
  Radar,
  ShieldCheck,
  Gauge,
  FileSearch,
  Sparkles,
  History,
  Settings,
  Download,
  User,
  Menu,
  X,
  LogOut,
} from 'lucide-react';
import type {
  AuthUser,
  ScanHistoryItem,
  ScanReport,
  ScanStageProgress,
  ScannerSettings,
} from './types/scan';
import { api, runStreamingScan } from './services/api';
import { exportScanReportPdf } from './utils/pdfReport';
import { AuthModal } from './components/AuthModal';
import { DashboardView, type NavSection } from './components/views/DashboardView';
import {
  AIRecommendationsView,
  PerformanceView,
  ScanHistoryView,
  SecurityAnalysisView,
  SeoAnalysisView,
  SettingsView,
  WebsiteScannerView,
} from './components/views/SectionViews';

const INITIAL_STAGES: ScanStageProgress[] = [
  { id: 'availability', label: 'Checking website availability', status: 'pending' },
  { id: 'security', label: 'Analyzing security configurations', status: 'pending' },
  { id: 'performance', label: 'Measuring performance', status: 'pending' },
  { id: 'seo', label: 'Checking SEO', status: 'pending' },
  { id: 'links', label: 'Analyzing links', status: 'pending' },
  { id: 'ai', label: 'Generating AI recommendations', status: 'pending' },
];

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'scanner', label: 'Website Scanner', icon: Radar },
  { id: 'security', label: 'Security Analysis', icon: ShieldCheck },
  { id: 'performance', label: 'Performance', icon: Gauge },
  { id: 'seo', label: 'SEO Analysis', icon: FileSearch },
  { id: 'ai', label: 'AI Recommendations', icon: Sparkles },
  { id: 'history', label: 'Scan History', icon: History },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function App() {
  const [activeNav, setActiveNav] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const [user, setUser] = useState<AuthUser | null>(null);
  const [settings, setSettings] = useState<ScannerSettings>({
    maxLinksToCheck: 12,
    requestTimeoutMs: 10000,
    requireAuthConfirmation: true,
  });
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [activeReport, setActiveReport] = useState<ScanReport | null>(null);

  const [urlInput, setUrlInput] = useState('');
  const [authorized, setAuthorized] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [scanStages, setScanStages] = useState<ScanStageProgress[]>(INITIAL_STAGES);
  const [scanError, setScanError] = useState<string | null>(null);
  const [reanalyzingAI, setReanalyzingAI] = useState(false);

  const hydrateWorkspace = useCallback(async () => {
    try {
      const [meRes, settingsRes, scansRes] = await Promise.all([
        api.getMe(),
        api.getSettings(),
        api.listScans(),
      ]);
      setUser(meRes.user);
      setSettings(settingsRes.settings);
      setHistory(scansRes.scans);

      if (scansRes.scans.length > 0 && !activeReport) {
        const latest = await api.getScan(scansRes.scans[0].id);
        setActiveReport(latest.report);
        setUrlInput(latest.report.url);
      }
    } catch {
      // Initial load may fail transiently if server is starting
    }
  }, [activeReport]);

  useEffect(() => {
    void hydrateWorkspace();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleRunScan = async (overrideUrl?: string) => {
    const target = (overrideUrl ?? urlInput).trim();
    if (!target) {
      setScanError('Enter a website URL to scan.');
      return;
    }
    if (settings.requireAuthConfirmation && !authorized) {
      setScanError(
        'Check the authorization box to confirm you own or have permission to test this website.'
      );
      return;
    }

    setScanError(null);
    setIsScanning(true);
    setShowProgress(true);
    setScanStages(
      INITIAL_STAGES.map((s) => ({
        ...s,
        status: 'pending',
        detail: undefined,
        durationMs: undefined,
      }))
    );

    try {
      await runStreamingScan(target, authorized || !settings.requireAuthConfirmation, {
        onStage: (evt) => {
          setScanStages((prev) =>
            prev.map((s) =>
              s.id === evt.id
                ? {
                    ...s,
                    status: evt.status,
                    detail: evt.detail ?? s.detail,
                    durationMs: evt.durationMs ?? s.durationMs,
                  }
                : s
            )
          );
        },
        onComplete: async (report) => {
          setActiveReport(report);
          setIsScanning(false);
          try {
            const refreshed = await api.listScans();
            setHistory(refreshed.scans);
          } catch {
            // ignore history refresh failure
          }
        },
        onError: (message) => {
          setScanError(message);
          setIsScanning(false);
          setScanStages((prev) =>
            prev.map((s) =>
              s.status === 'running' ? { ...s, status: 'error', detail: message } : s
            )
          );
        },
      });
    } catch (err) {
      setScanError(
        err instanceof Error ? err.message : 'Unexpected network error during scan.'
      );
      setIsScanning(false);
    }
  };

  const handleSelectHistory = async (id: string) => {
    try {
      const { report } = await api.getScan(id);
      setActiveReport(report);
      setUrlInput(report.url);
      setShowProgress(false);
      setScanError(null);
      if (activeNav === 'history') {
        setActiveNav('dashboard');
      }
    } catch (err) {
      setScanError(err instanceof Error ? err.message : 'Could not load scan report.');
    }
  };

  const handleDeleteHistory = async (id: string) => {
    try {
      await api.deleteScan(id);
      const remaining = history.filter((h) => h.id !== id);
      setHistory(remaining);
      if (activeReport?.id === id) {
        setActiveReport(null);
      }
    } catch {
      // ignore
    }
  };

  const handleReanalyzeAI = async () => {
    if (!activeReport) return;
    setReanalyzingAI(true);
    try {
      const { report } = await api.reanalyzeAI(activeReport.id);
      setActiveReport(report);
    } catch {
      // error is reflected in report.ai.errorMessage
    } finally {
      setReanalyzingAI(false);
    }
  };

  const handleSaveSettings = async (next: ScannerSettings) => {
    const res = await api.updateSettings(next);
    setSettings(res.settings);
  };

  const handleAuthenticated = async (authedUser: AuthUser) => {
    setUser(authedUser);
    const [settingsRes, scansRes] = await Promise.all([
      api.getSettings(),
      api.listScans(),
    ]);
    setSettings(settingsRes.settings);
    setHistory(scansRes.scans);
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
    const [settingsRes, scansRes] = await Promise.all([
      api.getSettings(),
      api.listScans(),
    ]);
    setSettings(settingsRes.settings);
    setHistory(scansRes.scans);
    setActiveReport(null);
  };

  const handleDownloadPdf = () => {
    if (activeReport) {
      exportScanReportPdf(activeReport);
    }
  };

  const currentNavLabel =
    NAV_ITEMS.find((item) => item.id === activeNav)?.label ?? 'Dashboard';

  return (
    <div className="min-h-screen bg-[#F2E8DA] text-[#3B2418] flex">
      {/* Desktop Left Sidebar — Espresso Brown (#3B2418, ~20% structural anchor) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#3B2418] text-[#F2E8DA] border-r border-[#2B1910]">
        <div className="h-16 px-5 border-b border-[#523424] flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-[#8EC5FF] flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4 text-[#3B2418]" />
          </div>
          <span className="font-display text-base font-bold tracking-tight text-[#F2E8DA] whitespace-nowrap">
            LaunchGuard AI
          </span>
        </div>

        <nav aria-label="Primary navigation" className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#8EC5FF] text-[#3B2418] font-semibold'
                    : 'text-[#EADFCF] hover:text-[#F2E8DA] hover:bg-[#4E3122]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-[#3B2418]' : 'text-[#C8B29A]'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#523424]">
          {user ? (
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-medium text-[#F2E8DA] truncate">{user.name}</p>
                <p className="text-[11px] font-mono text-[#D8C7B4] truncate">{user.email}</p>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                title="Sign out"
                aria-label="Sign out"
                className="p-2 text-[#D8C7B4] hover:text-[#F2E8DA] rounded cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="w-full py-2 px-3 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span>Sign In / Save History</span>
            </button>
          )}
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#3B2418]/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-64 max-w-[80vw] bg-[#3B2418] text-[#F2E8DA] border-r border-[#2B1910] flex flex-col">
            <div className="h-14 px-4 border-b border-[#523424] flex items-center justify-between">
              <span className="font-display text-sm font-bold text-[#F2E8DA]">
                LaunchGuard AI
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation"
                className="p-1.5 text-[#D8C7B4] hover:text-[#F2E8DA]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveNav(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium ${
                      isActive
                        ? 'bg-[#8EC5FF] text-[#3B2418] font-semibold'
                        : 'text-[#EADFCF] hover:text-[#F2E8DA]'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Column — Warm Cream (#F2E8DA, ~65–70%) */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Clean Contextual Top Bar */}
        <header className="sticky top-0 z-30 h-16 bg-[#F2E8DA]/95 backdrop-blur border-b border-[#D6C3AC] px-4 sm:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open menu"
              className="lg:hidden p-2 -ml-2 text-[#6E5041] hover:text-[#3B2418]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs text-[#6E5041] truncate">
              <span className="hidden sm:inline">Workspace</span>
              <span aria-hidden="true" className="hidden sm:inline text-[#B9A38D]">
                /
              </span>
              <span className="text-[#3B2418] font-semibold truncate">{currentNavLabel}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {activeReport && (
              <button
                type="button"
                onClick={handleDownloadPdf}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#3B2418] bg-[#FAF5EE] hover:bg-[#E9DCC9] border border-[#D4C1AA] rounded transition-colors whitespace-nowrap cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#3B2418]" />
                <span>PDF Report</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => (user ? setActiveNav('settings') : setAuthModalOpen(true))}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded transition-colors whitespace-nowrap cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span>{user ? user.name.split(' ')[0] : 'Sign In'}</span>
            </button>
          </div>
        </header>

        {/* Active View Viewport */}
        <main className="flex-1 w-full max-w-[1200px] mx-auto px-4 sm:px-8 py-8">
          {activeNav === 'dashboard' && (
            <DashboardView
              user={user}
              urlInput={urlInput}
              onUrlChange={setUrlInput}
              authorized={authorized}
              onAuthorizedChange={setAuthorized}
              settings={settings}
              isScanning={isScanning}
              scanError={scanError}
              scanStages={scanStages}
              showProgress={showProgress}
              activeReport={activeReport}
              history={history}
              onRunScan={handleRunScan}
              onSelectHistoryItem={handleSelectHistory}
              onNavigate={setActiveNav}
              onDownloadPdf={handleDownloadPdf}
            />
          )}

          {activeNav === 'scanner' && (
            <WebsiteScannerView
              report={activeReport}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'security' && (
            <SecurityAnalysisView
              report={activeReport}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'performance' && (
            <PerformanceView
              report={activeReport}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'seo' && (
            <SeoAnalysisView
              report={activeReport}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'ai' && (
            <AIRecommendationsView
              report={activeReport}
              reanalyzing={reanalyzingAI}
              onReanalyze={handleReanalyzeAI}
              onDownloadPdf={handleDownloadPdf}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'history' && (
            <ScanHistoryView
              history={history}
              activeId={activeReport?.id}
              onSelect={handleSelectHistory}
              onDelete={handleDeleteHistory}
              onGoToDashboard={() => setActiveNav('dashboard')}
            />
          )}

          {activeNav === 'settings' && (
            <SettingsView
              user={user}
              settings={settings}
              onSaveSettings={handleSaveSettings}
              onOpenAuth={() => setAuthModalOpen(true)}
              onLogout={handleLogout}
              onNavigate={setActiveNav}
            />
          )}
        </main>
      </div>

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthenticated={handleAuthenticated}
      />
    </div>
  );
}

export default App;
