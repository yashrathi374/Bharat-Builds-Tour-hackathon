import React from 'react';

interface ScoreRingProps {
  score: number;
  grade: string;
  size?: number;
}

export const ScoreRing: React.FC<ScoreRingProps> = ({ score, grade, size = 148 }) => {
  const strokeWidth = 9;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, score));
  const offset = circumference - (clamped / 100) * circumference;

  const strokeColor =
    clamped >= 80 ? '#15803D' : clamped >= 60 ? '#B45309' : '#B91C1C';

  const textTone =
    clamped >= 80
      ? 'text-[#15803D]'
      : clamped >= 60
        ? 'text-[#B45309]'
        : 'text-[#B91C1C]';

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#E3D4C0"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="butt"
          className="transition-[stroke-dashoffset] duration-500 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="font-mono text-4xl font-semibold tracking-tight text-[#3B2418] tabular-nums leading-none">
          {clamped}
        </span>
        <span className="mt-1.5 text-xs text-[#6E5041] font-mono tabular-nums">/ 100</span>
        <span className={`mt-1 text-[11px] font-semibold ${textTone}`}>{grade}</span>
      </div>
    </div>
  );
};
