import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Trash2,
  RefreshCw,
  Download,
  Loader2,
  Search,
  Check,
  Shield,
} from 'lucide-react';
import type {
  AuthUser,
  ScanHistoryItem,
  ScanReport,
  ScannerSettings,
} from '../../types/scan';
import { FindingAccordion } from '../FindingAccordion';
import type { NavSection } from './DashboardView';

interface EmptyReportNoticeProps {
  title: string;
  description: string;
  onGoToDashboard: () => void;
}

const EmptyReportNotice: React.FC<EmptyReportNoticeProps> = ({
  title,
  description,
  onGoToDashboard,
}) => (
  <div className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-8 text-center max-w-xl mx-auto my-8">
    <h2 className="text-base font-semibold text-[#3B2418]">{title}</h2>
    <p className="mt-2 text-sm text-[#6E5041] leading-relaxed">{description}</p>
    <button
      type="button"
      onClick={onGoToDashboard}
      className="mt-5 px-5 py-2.5 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded transition-colors cursor-pointer"
    >
      Run a Website Scan
    </button>
  </div>
);

/* ============================================================================
   1. WEBSITE SCANNER & BROKEN LINK CHECKER VIEW
   ============================================================================ */
export const WebsiteScannerView: React.FC<{
  report: ScanReport | null;
  onGoToDashboard: () => void;
}> = ({ report, onGoToDashboard }) => {
  const [linkFilter, setLinkFilter] = useState<'all' | 'broken' | 'healthy'>('all');

  if (!report) {
    return (
      <EmptyReportNotice
        title="No active website scan loaded"
        description="Run a live scan from the Dashboard to inspect HTTP availability, redirect chains, DNS resolution, and internal broken links."
        onGoToDashboard={onGoToDashboard}
      />
    );
  }

  const filteredLinks = report.links.links.filter((l) => {
    if (linkFilter === 'broken') return !l.ok;
    if (linkFilter === 'healthy') return l.ok;
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-[#3B2418]">
          Website Scanner &amp; Link Verification
        </h1>
        <p className="mt-1 text-sm text-[#6E5041] font-mono break-all">
          {report.finalUrl}
        </p>
      </div>

      {/* Availability Key Metrics Strip */}
      <div className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-[#E4D6C4]">
        <div className="p-5">
          <p className="text-xs text-[#6E5041]">HTTP Response</p>
          <p
            className={`mt-2 font-mono text-2xl font-semibold tabular-nums ${
              report.availability.statusCode >= 200 && report.availability.statusCode < 400
                ? 'text-[#15803D]'
                : 'text-[#B91C1C]'
            }`}
          >
            {report.availability.statusCode} {report.availability.statusText}
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E] truncate">
            {report.availability.contentType}
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">Response Time</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {report.availability.responseTimeMs} ms
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E] font-mono">
            IP: {report.availability.resolvedIp}
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">Protocol &amp; HTTPS</p>
          <p
            className={`mt-2 font-mono text-2xl font-semibold ${
              report.availability.isHttps ? 'text-[#15803D]' : 'text-[#B91C1C]'
            }`}
          >
            {report.availability.isHttps ? 'HTTPS' : 'HTTP Only'}
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E]">
            HTTP redirect:{' '}
            {report.availability.httpToHttpsRedirect === true
              ? 'Enforced'
              : report.availability.httpToHttpsRedirect === false
                ? 'Not enforced'
                : 'Not verified'}
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">Redirects</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {report.availability.redirectChain.length} hop
            {report.availability.redirectChain.length === 1 ? '' : 's'}
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E]">
            Availability score: {report.score.categories.availability}/100
          </p>
        </div>
      </div>

      {/* Redirect Chain Trace */}
      {report.availability.redirectChain.length > 0 && (
        <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
          <div className="px-5 py-3.5 bg-[#3B2418] text-[#F2E8DA]">
            <h2 className="text-sm font-semibold">Redirect Chain</h2>
          </div>
          <ol className="divide-y divide-[#E4D6C4] text-xs font-mono">
            {report.availability.redirectChain.map((hop, idx) => (
              <li
                key={idx}
                className="px-5 py-3 flex flex-wrap items-center justify-between gap-3"
              >
                <div className="flex flex-wrap items-center gap-2 min-w-0">
                  <span className="px-1.5 py-0.5 rounded bg-[#8EC5FF] text-[#3B2418] font-semibold tabular-nums">
                    HTTP {hop.statusCode}
                  </span>
                  <span className="text-[#6E5041] truncate max-w-md">{hop.from}</span>
                  <span className="text-[#8C6D5C]">-&gt;</span>
                  <span className="text-[#3B2418] font-medium truncate max-w-md">{hop.to}</span>
                </div>
                <span className="text-[#7D5E4E] tabular-nums">{hop.durationMs} ms</span>
              </li>
            ))}
          </ol>
        </section>
      )}

      {/* Broken Link Checker */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4] flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-[#3B2418]">
              Internal Broken Link Checker
            </h2>
            <p className="text-xs text-[#6E5041] mt-0.5 font-mono tabular-nums">
              {report.links.totalExtractedLinks} total links extracted ·{' '}
              {report.links.internalLinksFound} internal · {report.links.checkedCount} verified
              (capped at {report.links.maxCheckedLimit} with safe pacing)
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#F2E8DA] border border-[#D4C1AA] rounded">
            {(['all', 'broken', 'healthy'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setLinkFilter(tab)}
                className={`px-3 py-1 text-xs font-medium rounded transition-colors capitalize cursor-pointer ${
                  linkFilter === tab
                    ? 'bg-[#8EC5FF] text-[#3B2418] font-semibold'
                    : 'text-[#6E5041] hover:text-[#3B2418]'
                }`}
              >
                {tab}{' '}
                {tab === 'all'
                  ? `(${report.links.links.length})`
                  : tab === 'broken'
                    ? `(${report.links.brokenCount})`
                    : `(${report.links.healthyCount})`}
              </button>
            ))}
          </div>
        </div>

        {filteredLinks.length === 0 ? (
          <div className="px-5 py-8 text-sm text-[#6E5041] text-center">
            {report.links.links.length === 0
              ? 'No same-origin sub-page links were found in this document.'
              : 'No links match the selected filter.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2B1910] bg-[#3B2418] text-xs text-[#F2E8DA]">
                  <th className="py-2.5 px-5 font-semibold">Internal URL</th>
                  <th className="py-2.5 px-4 font-semibold">Anchor Text</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Status</th>
                  <th className="py-2.5 px-5 font-semibold text-right">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E4D6C4] text-xs">
                {filteredLinks.map((link) => (
                  <tr key={link.url} className="hover:bg-[#F2E8DA]/70">
                    <td className="py-3 px-5 font-mono text-[#3B2418] max-w-md truncate">
                      <a
                        href={link.url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 hover:underline decoration-[#8EC5FF] decoration-2"
                      >
                        <span className="truncate max-w-sm">{link.url}</span>
                        <ExternalLink className="w-3 h-3 shrink-0 text-[#7D5E4E]" />
                      </a>
                    </td>
                    <td className="py-3 px-4 text-[#6E5041] max-w-xs truncate">
                      {link.anchorText}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                      {link.ok ? (
                        <span className="text-[#15803D] font-semibold">
                          HTTP {link.statusCode}
                        </span>
                      ) : (
                        <span className="text-[#B91C1C] font-semibold">
                          {link.statusCode ? `HTTP ${link.statusCode}` : link.error || 'Failed'}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-5 text-right font-mono text-[#6E5041] tabular-nums whitespace-nowrap">
                      {link.responseTimeMs} ms
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};

/* ============================================================================
   2. SECURITY CONFIGURATION ANALYSIS VIEW
   ============================================================================ */
export const SecurityAnalysisView: React.FC<{
  report: ScanReport | null;
  onGoToDashboard: () => void;
}> = ({ report, onGoToDashboard }) => {
  if (!report) {
    return (
      <EmptyReportNotice
        title="No security report available yet"
        description="Run a scan from the Dashboard to inspect SSL/TLS certificate validity, HTTP security headers, and server fingerprinting."
        onGoToDashboard={onGoToDashboard}
      />
    );
  }

  const { security } = report;
  const headerEntries = [
    { key: 'content-security-policy', label: 'Content-Security-Policy' },
    { key: 'strict-transport-security', label: 'Strict-Transport-Security' },
    { key: 'x-frame-options', label: 'X-Frame-Options' },
    { key: 'x-content-type-options', label: 'X-Content-Type-Options' },
    { key: 'referrer-policy', label: 'Referrer-Policy' },
    { key: 'permissions-policy', label: 'Permissions-Policy' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#3B2418]">
            Security Configuration Analysis
          </h1>
          <p className="mt-1 text-sm text-[#6E5041]">{security.scopeDisclaimer}</p>
        </div>
        <div className="font-mono text-sm tabular-nums text-[#3B2418]">
          Security Score:{' '}
          <span
            className={
              report.score.categories.security >= 80
                ? 'text-[#15803D] font-semibold'
                : report.score.categories.security >= 60
                  ? 'text-[#B45309] font-semibold'
                  : 'text-[#B91C1C] font-semibold'
            }
          >
            {report.score.categories.security} / 100
          </span>
        </div>
      </div>

      {/* TLS / SSL Certificate Panel */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 bg-[#3B2418] text-[#F2E8DA] flex items-center justify-between gap-3">
          <h2 className="text-base font-semibold">SSL / TLS Certificate Details</h2>
          <span
            className={`text-xs font-semibold px-2.5 py-0.5 rounded ${
              security.tls.valid
                ? 'bg-[#8EC5FF] text-[#3B2418]'
                : 'bg-[#FEE2E2] text-[#991B1B]'
            }`}
          >
            {security.tls.valid
              ? 'Valid & Trusted'
              : security.tls.available
                ? 'Certificate Issue'
                : 'No TLS'}
          </span>
        </div>

        {security.tls.available ? (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-[#E4D6C4] text-sm">
            <div className="p-5 space-y-3">
              <div>
                <dt className="text-xs text-[#6E5041]">Common Name (Subject)</dt>
                <dd className="mt-1 font-mono text-xs text-[#3B2418] font-medium">
                  {security.tls.subject || '—'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-[#6E5041]">Certificate Authority (Issuer)</dt>
                <dd className="mt-1 font-mono text-xs text-[#4B3123]">
                  {security.tls.issuer || '—'}
                </dd>
              </div>
            </div>

            <div className="p-5 space-y-3">
              <div>
                <dt className="text-xs text-[#6E5041]">Valid Until</dt>
                <dd className="mt-1 font-mono text-xs text-[#3B2418] tabular-nums font-medium">
                  {security.tls.validTo
                    ? new Date(security.tls.validTo).toLocaleDateString()
                    : '—'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-[#6E5041]">Days Remaining</dt>
                <dd
                  className={`mt-1 font-mono text-xs font-semibold tabular-nums ${
                    typeof security.tls.daysRemaining === 'number' &&
                    security.tls.daysRemaining > 14
                      ? 'text-[#15803D]'
                      : 'text-[#B45309]'
                  }`}
                >
                  {typeof security.tls.daysRemaining === 'number'
                    ? `${security.tls.daysRemaining} days`
                    : '—'}
                </dd>
              </div>
            </div>

            <div className="p-5 space-y-3">
              <div>
                <dt className="text-xs text-[#6E5041]">TLS Protocol &amp; Cipher</dt>
                <dd className="mt-1 font-mono text-xs text-[#3B2418] font-medium">
                  {security.tls.protocol || 'Unknown'} · {security.tls.cipher || 'Unknown'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-[#6E5041]">Server Exposure Headers</dt>
                <dd className="mt-1 font-mono text-xs text-[#4B3123]">
                  Server: {security.serverExposure.serverHeader ?? 'Omitted'} / X-Powered-By:{' '}
                  {security.serverExposure.poweredByHeader ?? 'Omitted'}
                </dd>
              </div>
            </div>
          </dl>
        ) : (
          <div className="p-5 text-sm text-[#991B1B]">
            {security.tls.error || 'No TLS certificate detected on this endpoint.'}
          </div>
        )}
      </section>

      {/* HTTP Security Headers Matrix */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4]">
          <h2 className="text-base font-semibold text-[#3B2418]">
            HTTP Security Headers Matrix
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#2B1910] bg-[#3B2418] text-xs text-[#F2E8DA]">
                <th className="py-2.5 px-5 font-semibold">Header</th>
                <th className="py-2.5 px-4 font-semibold">Status</th>
                <th className="py-2.5 px-5 font-semibold">Observed Value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E4D6C4] text-xs">
              {headerEntries.map((entry) => {
                const value = security.headers[entry.key];
                return (
                  <tr key={entry.key}>
                    <td className="py-3 px-5 font-mono font-medium text-[#3B2418] whitespace-nowrap">
                      {entry.label}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {value ? (
                        <span className="inline-flex items-center gap-1.5 text-[#15803D] font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Present
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-[#B45309] font-semibold">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          Missing
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-5 font-mono text-[#6E5041] break-all">
                      {value ?? '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Security Findings & Fix Guides */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4]">
          <h2 className="text-base font-semibold text-[#3B2418]">
            Security Checks &amp; Remediation Guides
          </h2>
        </div>
        <FindingAccordion findings={security.findings} defaultOpenFirst />
      </section>
    </div>
  );
};

/* ============================================================================
   3. PERFORMANCE ANALYZER VIEW
   ============================================================================ */
export const PerformanceView: React.FC<{
  report: ScanReport | null;
  onGoToDashboard: () => void;
}> = ({ report, onGoToDashboard }) => {
  if (!report) {
    return (
      <EmptyReportNotice
        title="No performance data yet"
        description="Run a scan from the Dashboard to measure real server response time, HTML payload size, compression, images, and external asset counts."
        onGoToDashboard={onGoToDashboard}
      />
    );
  }

  const { performance } = report;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#3B2418]">Performance Analyzer</h1>
          <p className="mt-1 text-sm text-[#6E5041]">
            Measured directly from the initial HTTP response and parsed DOM assets.
          </p>
        </div>
        <div className="font-mono text-sm tabular-nums text-[#3B2418]">
          Performance Score:{' '}
          <span
            className={
              report.score.categories.performance >= 80
                ? 'text-[#15803D] font-semibold'
                : report.score.categories.performance >= 60
                  ? 'text-[#B45309] font-semibold'
                  : 'text-[#B91C1C] font-semibold'
            }
          >
            {report.score.categories.performance} / 100
          </span>
        </div>
      </div>

      <div className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-[#E4D6C4]">
        <div className="p-5">
          <p className="text-xs text-[#6E5041]">Server Response Time</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {performance.responseTimeMs} ms
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E]">Target &lt;= 600 ms</p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">HTML Page Size</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {performance.htmlSizeKb} KB
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E] font-mono">
            Encoding: {performance.contentEncoding ?? 'none'}
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">Images in HTML</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {performance.imageCount}
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
            {performance.imagesWithoutLazyLoading} non-lazy · {performance.imagesWithoutDimensions}{' '}
            unsized
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs text-[#6E5041]">External Resources</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-[#3B2418] tabular-nums">
            {performance.totalExternalResources}
          </p>
          <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
            {performance.externalScriptCount} scripts · {performance.externalStylesheetCount} CSS
          </p>
        </div>
      </div>

      {/* Caching & Third-party domains */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-sm font-semibold text-[#3B2418]">Caching &amp; Scripts</h2>
          <dl className="mt-3 space-y-2 text-xs">
            <div className="flex justify-between gap-4 py-1.5 border-b border-[#E4D6C4]">
              <dt className="text-[#6E5041]">Cache-Control Header</dt>
              <dd className="font-mono text-[#3B2418] text-right">
                {performance.cacheControl ?? 'Not set'}
              </dd>
            </div>
            <div className="flex justify-between gap-4 py-1.5 border-b border-[#E4D6C4]">
              <dt className="text-[#6E5041]">Inline Script Blocks</dt>
              <dd className="font-mono text-[#3B2418] tabular-nums">
                {performance.inlineScriptCount}
              </dd>
            </div>
            <div className="flex justify-between gap-4 py-1.5">
              <dt className="text-[#6E5041]">Raw HTML Bytes</dt>
              <dd className="font-mono text-[#3B2418] tabular-nums">
                {performance.htmlSizeBytes.toLocaleString()} bytes
              </dd>
            </div>
          </dl>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-[#3B2418]">
            Third-Party Resource Domains ({performance.externalDomains.length})
          </h2>
          {performance.externalDomains.length === 0 ? (
            <p className="mt-3 text-xs text-[#6E5041]">
              No third-party script or stylesheet hosts detected in the initial HTML.
            </p>
          ) : (
            <ul className="mt-3 space-y-1.5 text-xs font-mono text-[#4B3123]">
              {performance.externalDomains.map((domain) => (
                <li key={domain} className="truncate">
                  {domain}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4]">
          <h2 className="text-base font-semibold text-[#3B2418]">
            Performance Checks &amp; Optimization Opportunities
          </h2>
        </div>
        <FindingAccordion findings={performance.findings} defaultOpenFirst />
      </section>
    </div>
  );
};

/* ============================================================================
   4. SEO ANALYSIS VIEW
   ============================================================================ */
export const SeoAnalysisView: React.FC<{
  report: ScanReport | null;
  onGoToDashboard: () => void;
}> = ({ report, onGoToDashboard }) => {
  if (!report) {
    return (
      <EmptyReportNotice
        title="No SEO analysis available yet"
        description="Run a scan from the Dashboard to extract your page title, meta description, heading hierarchy, OpenGraph social tags, and accessibility alt text."
        onGoToDashboard={onGoToDashboard}
      />
    );
  }

  const { seo } = report;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#3B2418]">SEO &amp; Discoverability</h1>
          <p className="mt-1 text-sm text-[#6E5041]">
            Metadata and document structure extracted directly from the live HTML response.
          </p>
        </div>
        <div className="font-mono text-sm tabular-nums text-[#3B2418]">
          SEO Score:{' '}
          <span
            className={
              report.score.categories.seo >= 80
                ? 'text-[#15803D] font-semibold'
                : report.score.categories.seo >= 60
                  ? 'text-[#B45309] font-semibold'
                  : 'text-[#B91C1C] font-semibold'
            }
          >
            {report.score.categories.seo} / 100
          </span>
        </div>
      </div>

      {/* Live Search Result Snippet Preview */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-5">
        <p className="text-xs font-medium text-[#6E5041] mb-3">
          Search Engine Snippet Preview (from live tags)
        </p>
        <div className="max-w-2xl bg-[#F2E8DA] border border-[#D4C1AA] rounded p-4 space-y-1">
          <p className="text-xs font-mono text-[#6E5041] truncate">{report.finalUrl}</p>
          <p className="text-base font-semibold text-[#3B7BBF] leading-snug">
            {seo.title || '(Missing <title> tag)'}
          </p>
          <p className="text-xs text-[#3B2418] leading-relaxed">
            {seo.metaDescription ||
              'No meta description found. Search engines will generate an automatic snippet from visible page text.'}
          </p>
        </div>
      </section>

      {/* Extracted Metadata Table */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4]">
          <h2 className="text-base font-semibold text-[#3B2418]">Extracted HTML Metadata</h2>
        </div>
        <dl className="divide-y divide-[#E4D6C4] text-xs">
          {[
            {
              label: 'Document Title',
              val: seo.title ? `${seo.title} (${seo.titleLength} chars)` : 'Missing',
            },
            {
              label: 'Meta Description',
              val: seo.metaDescription
                ? `${seo.metaDescription} (${seo.metaDescriptionLength} chars)`
                : 'Missing',
            },
            { label: 'Canonical URL', val: seo.canonicalUrl || 'Not specified' },
            {
              label: 'Primary Headings (<h1>)',
              val:
                seo.h1Count > 0
                  ? `${seo.h1Count} found — ${seo.h1Texts.slice(0, 2).join(' / ')}`
                  : '0 found in initial HTML',
            },
            { label: 'Viewport Meta', val: seo.viewportMeta || 'Missing' },
            { label: 'HTML Lang Attribute', val: seo.htmlLang || 'Missing' },
            { label: 'OpenGraph Title', val: seo.ogTitle || 'Missing' },
            { label: 'OpenGraph Description', val: seo.ogDescription || 'Missing' },
            {
              label: 'Image Alt Attribute Coverage',
              val:
                seo.totalImages > 0
                  ? `${seo.totalImages - seo.imagesMissingAlt} of ${seo.totalImages} images have alt text`
                  : 'No <img> tags in initial HTML',
            },
          ].map((row) => (
            <div key={row.label} className="px-5 py-3 grid grid-cols-1 sm:grid-cols-3 gap-2">
              <dt className="text-[#6E5041] font-medium">{row.label}</dt>
              <dd className="sm:col-span-2 font-mono text-[#3B2418] break-words">{row.val}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4]">
          <h2 className="text-base font-semibold text-[#3B2418]">
            SEO Findings &amp; Fix Instructions
          </h2>
        </div>
        <FindingAccordion findings={seo.findings} defaultOpenFirst />
      </section>
    </div>
  );
};

/* ============================================================================
   5. AI WEBSITE ANALYST RECOMMENDATIONS VIEW
   ============================================================================ */
export const AIRecommendationsView: React.FC<{
  report: ScanReport | null;
  reanalyzing: boolean;
  onReanalyze: () => void;
  onDownloadPdf: () => void;
  onGoToDashboard: () => void;
}> = ({ report, reanalyzing, onReanalyze, onDownloadPdf, onGoToDashboard }) => {
  const [checkedTasks, setCheckedTasks] = useState<Record<number, boolean>>({});

  if (!report) {
    return (
      <EmptyReportNotice
        title="No AI analysis to display"
        description="Complete a live website scan first. LaunchGuard AI sends the real scan output to Gemini on our backend to generate beginner-friendly fix guides."
        onGoToDashboard={onGoToDashboard}
      />
    );
  }

  const { ai } = report;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#3B2418]">AI Website Analyst</h1>
          <p className="mt-1 text-sm text-[#6E5041]">
            Grounded strictly in verified scan results for{' '}
            <span className="font-mono text-[#3B2418] font-medium">{report.finalUrl}</span>
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            disabled={reanalyzing}
            onClick={onReanalyze}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded transition-colors cursor-pointer disabled:opacity-50"
          >
            {reanalyzing ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5" />
            )}
            <span>Regenerate AI Review</span>
          </button>
          <button
            type="button"
            onClick={onDownloadPdf}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#F2E8DA] bg-[#3B2418] hover:bg-[#2C1A11] rounded transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#8EC5FF]" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {ai.status !== 'completed' ? (
        <section className="bg-[#FAF5EE] border border-[#B45309]/40 rounded-lg p-6 space-y-3">
          <h2 className="text-base font-semibold text-[#B45309]">
            AI Website Analyst Unavailable for This Scan
          </h2>
          <p className="text-sm text-[#3B2418] leading-relaxed">
            {ai.errorMessage ||
              'The server could not generate an AI review. All deterministic security, performance, SEO, and link findings remain accurate.'}
          </p>
          <button
            type="button"
            disabled={reanalyzing}
            onClick={onReanalyze}
            className="px-4 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded cursor-pointer disabled:opacity-50"
          >
            Retry AI Analysis
          </button>
        </section>
      ) : (
        <>
          {/* Executive Summary */}
          <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
            <div className="px-6 py-4 bg-[#3B2418] text-[#F2E8DA] flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-base font-semibold">Executive Audit Summary</h2>
              {ai.generatedAt && (
                <span className="text-xs font-mono text-[#D8C7B4] tabular-nums">
                  Generated {new Date(ai.generatedAt).toLocaleTimeString()}
                </span>
              )}
            </div>
            <div className="p-6 space-y-4">
              <p className="text-sm text-[#3B2418] leading-relaxed max-w-4xl">
                {ai.executiveSummary}
              </p>
              {ai.launchVerdict && (
                <p className="text-sm font-semibold text-[#3B2418] bg-[#8EC5FF]/25 border border-[#8EC5FF]/60 rounded px-3.5 py-2.5">
                  Verdict: {ai.launchVerdict}
                </p>
              )}
            </div>
          </section>

          {/* Prioritized Plain-Language Fixes */}
          {ai.prioritizedFixes && ai.prioritizedFixes.length > 0 && (
            <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
              <div className="px-5 py-4 border-b border-[#E4D6C4]">
                <h2 className="text-base font-semibold text-[#3B2418]">
                  Prioritized Beginner-Friendly Fix Guides
                </h2>
                <p className="text-xs text-[#6E5041] mt-0.5">
                  Every recommendation below corresponds to a real finding from your scan
                </p>
              </div>
              <div className="divide-y divide-[#E4D6C4]">
                {ai.prioritizedFixes.map((fix, idx) => (
                  <article key={idx} className="p-5 space-y-4">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="font-mono text-xs text-[#7D5E4E] tabular-nums">
                        0{idx + 1}.
                      </span>
                      <h3 className="text-sm font-semibold text-[#3B2418]">
                        {fix.findingTitle}
                      </h3>
                      <span aria-hidden="true" className="text-[#C8B59E]">
                        ·
                      </span>
                      <span
                        className={`text-xs font-semibold capitalize ${
                          fix.severity === 'critical'
                            ? 'text-[#B91C1C]'
                            : fix.severity === 'high'
                              ? 'text-[#C2410C]'
                              : fix.severity === 'medium'
                                ? 'text-[#B45309]'
                                : 'text-[#3B7BBF]'
                        }`}
                      >
                        {fix.severity} priority
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">
                          What is happening
                        </p>
                        <p className="text-[#3B2418] leading-relaxed">
                          {fix.plainEnglishExplanation}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">Why it matters</p>
                        <p className="text-[#3B2418] leading-relaxed">{fix.whyItMatters}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">Potential risk</p>
                        <p className="text-[#3B2418] leading-relaxed">{fix.potentialRisk}</p>
                      </div>
                    </div>

                    <div className="bg-[#F2E8DA] border border-[#D4C1AA] rounded p-4 space-y-3">
                      <p className="text-xs font-semibold text-[#3B2418]">
                        Step-by-step instructions
                      </p>
                      <ol className="space-y-1.5 text-sm text-[#3B2418]">
                        {fix.stepByStepFix.map((step, sIdx) => (
                          <li key={sIdx} className="flex items-start gap-2.5">
                            <span className="font-mono text-xs font-semibold bg-[#8EC5FF] text-[#3B2418] px-1.5 py-0.5 rounded tabular-nums mt-0.5">
                              {sIdx + 1}
                            </span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                      <p className="text-xs text-[#6E5041] pt-2 border-t border-[#DFD0BE]">
                        <span className="text-[#3B2418] font-semibold">How to verify:</span>{' '}
                        {fix.howToVerify}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          )}

          {/* Launch Checklist + Plain-English Glossary */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {ai.launchChecklist && ai.launchChecklist.length > 0 && (
              <section className="lg:col-span-7 bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
                <div className="px-5 py-4 border-b border-[#E4D6C4]">
                  <h2 className="text-base font-semibold text-[#3B2418]">
                    Interactive Launch Checklist
                  </h2>
                </div>
                <ul className="divide-y divide-[#E4D6C4]">
                  {ai.launchChecklist.map((item, idx) => {
                    const isChecked =
                      checkedTasks[idx] !== undefined ? checkedTasks[idx] : item.completed;
                    return (
                      <li key={idx} className="px-5 py-3">
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() =>
                              setCheckedTasks((prev) => ({ ...prev, [idx]: !isChecked }))
                            }
                            className="mt-1 w-4 h-4 accent-[#3B2418]"
                          />
                          <div className="min-w-0">
                            <p
                              className={`text-sm ${
                                isChecked
                                  ? 'line-through text-[#8C6D5C]'
                                  : 'text-[#3B2418]'
                              }`}
                            >
                              {item.task}
                            </p>
                            <p className="text-xs text-[#7D5E4E] mt-0.5">
                              {item.category} · {item.priority}
                            </p>
                          </div>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              </section>
            )}

            {ai.glossary && ai.glossary.length > 0 && (
              <section className="lg:col-span-5 bg-[#3B2418] text-[#F2E8DA] border border-[#2B1910] rounded-lg overflow-hidden">
                <div className="px-5 py-4 border-b border-[#523424]">
                  <h2 className="text-base font-semibold text-[#F2E8DA]">
                    Technical Terms Explained Simply
                  </h2>
                </div>
                <dl className="divide-y divide-[#523424]">
                  {ai.glossary.map((entry, idx) => (
                    <div key={idx} className="px-5 py-3.5">
                      <dt className="text-xs font-mono font-semibold text-[#8EC5FF]">
                        {entry.term}
                      </dt>
                      <dd className="mt-1 text-xs text-[#EADFCF] leading-relaxed">
                        {entry.simpleExplanation}
                      </dd>
                    </div>
                  ))}
                </dl>
              </section>
            )}
          </div>
        </>
      )}
    </div>
  );
};

/* ============================================================================
   6. SCAN HISTORY VIEW
   ============================================================================ */
export const ScanHistoryView: React.FC<{
  history: ScanHistoryItem[];
  activeId?: string;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onGoToDashboard: () => void;
}> = ({ history, activeId, onSelect, onDelete, onGoToDashboard }) => {
  const [query, setQuery] = useState('');

  const filtered = history.filter(
    (item) =>
      item.url.toLowerCase().includes(query.toLowerCase()) ||
      item.finalUrl.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#3B2418]">Scan History</h1>
          <p className="mt-1 text-sm text-[#6E5041]">
            Persistent audit log stored in your SQLite workspace database. Click any row to
            reopen the full report.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search
            className="w-4 h-4 text-[#7D5E4E] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by domain or URL..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF5EE] border border-[#D4C1AA] rounded text-[#3B2418] placeholder-[#8C6D5C] focus:border-[#3B2418] focus:outline-none"
          />
        </div>
      </div>

      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm text-[#6E5041]">
              {history.length === 0
                ? 'No scans saved yet.'
                : 'No scans match your search filter.'}
            </p>
            {history.length === 0 && (
              <button
                type="button"
                onClick={onGoToDashboard}
                className="mt-4 px-4 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded cursor-pointer"
              >
                Start First Scan
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2B1910] bg-[#3B2418] text-xs text-[#F2E8DA]">
                  <th className="py-3 px-5 font-semibold">Website URL</th>
                  <th className="py-3 px-4 font-semibold text-right">Overall</th>
                  <th className="py-3 px-4 font-semibold text-right">Sec</th>
                  <th className="py-3 px-4 font-semibold text-right">Perf</th>
                  <th className="py-3 px-4 font-semibold text-right">SEO</th>
                  <th className="py-3 px-4 font-semibold text-right">Checks</th>
                  <th className="py-3 px-4 font-semibold text-right">Date</th>
                  <th className="py-3 px-5 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E4D6C4] text-xs">
                {filtered.map((item) => (
                  <tr
                    key={item.id}
                    onClick={() => onSelect(item.id)}
                    className={`cursor-pointer transition-colors ${
                      activeId === item.id ? 'bg-[#8EC5FF]/25' : 'hover:bg-[#F2E8DA]/70'
                    }`}
                  >
                    <td className="py-3 px-5 font-mono font-medium text-[#3B2418] max-w-sm truncate">
                      {item.finalUrl}
                    </td>
                    <td
                      className={`py-3 px-4 text-right font-mono font-semibold tabular-nums ${
                        item.overallScore >= 80
                          ? 'text-[#15803D]'
                          : item.overallScore >= 60
                            ? 'text-[#B45309]'
                            : 'text-[#B91C1C]'
                      }`}
                    >
                      {item.overallScore}/100
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#4B3123] tabular-nums">
                      {item.securityScore}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#4B3123] tabular-nums">
                      {item.performanceScore}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#4B3123] tabular-nums">
                      {item.seoScore}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                      <span className="text-[#15803D] font-medium">{item.passedCount}P</span> /{' '}
                      <span className="text-[#B45309] font-medium">{item.warningCount}W</span> /{' '}
                      <span className="text-[#B91C1C] font-medium">{item.failedCount}F</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-[#7D5E4E] tabular-nums whitespace-nowrap">
                      {new Date(item.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-5 text-right">
                      <button
                        type="button"
                        aria-label={`Delete scan for ${item.finalUrl}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(item.id);
                        }}
                        className="p-1.5 text-[#7D5E4E] hover:text-[#B91C1C] rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};

/* ============================================================================
   7. SETTINGS & FUTURE-READY ARCHITECTURE VIEW
   ============================================================================ */
export const SettingsView: React.FC<{
  user: AuthUser | null;
  settings: ScannerSettings;
  onSaveSettings: (next: ScannerSettings) => Promise<void>;
  onOpenAuth: () => void;
  onLogout: () => void;
  onNavigate: (sec: NavSection) => void;
}> = ({ user, settings, onSaveSettings, onOpenAuth, onLogout }) => {
  const [maxLinks, setMaxLinks] = useState(settings.maxLinksToCheck);
  const [timeoutMs, setTimeoutMs] = useState(settings.requestTimeoutMs);
  const [requireConfirm, setRequireConfirm] = useState(settings.requireAuthConfirmation);
  const [saving, setSaving] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedToast(false);
    try {
      await onSaveSettings({
        maxLinksToCheck: maxLinks,
        requestTimeoutMs: timeoutMs,
        requireAuthConfirmation: requireConfirm,
      });
      setSavedToast(true);
      setTimeout(() => setSavedToast(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  const plannedModules = [
    'GitHub Repository Integration & PR Gatekeeper',
    'Source-Code Static Vulnerability Scanning (SAST)',
    'Automated Bug Detection & AI Code-Fix Generation',
    'Scheduled Continuous Website Monitoring & Alerts',
    'API & Database Security Posture Analysis',
    'Controlled Load Testing & AI Deployment Assistant',
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-semibold text-[#3B2418]">Workspace Settings</h1>
        <p className="mt-1 text-sm text-[#6E5041]">
          Configure scanner safety limits, manage your account session, and inspect built-in SSRF protections.
        </p>
      </div>

      {/* Account Section */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-[#3B2418]">Account &amp; Persistence</h2>
          {user ? (
            <p className="mt-1 text-xs text-[#6E5041]">
              Signed in as <span className="text-[#3B2418] font-semibold">{user.name}</span> (
              <span className="font-mono">{user.email}</span>)
            </p>
          ) : (
            <p className="mt-1 text-xs text-[#6E5041]">
              Using local browser workspace session. Sign in or create an account to tie scan history to your credentials.
            </p>
          )}
        </div>

        {user ? (
          <button
            type="button"
            onClick={onLogout}
            className="px-4 py-2 text-xs font-medium text-[#F2E8DA] bg-[#3B2418] hover:bg-[#2C1A11] rounded cursor-pointer"
          >
            Sign Out
          </button>
        ) : (
          <button
            type="button"
            onClick={onOpenAuth}
            className="px-4 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] rounded cursor-pointer"
          >
            Sign In / Create Account
          </button>
        )}
      </section>

      {/* Scanner Policy Form */}
      <form
        onSubmit={handleSave}
        className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-6 space-y-5"
      >
        <h2 className="text-base font-semibold text-[#3B2418]">Scanner Safety Controls</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label
              htmlFor="setting-max-links"
              className="block text-xs font-medium text-[#3B2418] mb-1.5"
            >
              Max Internal Links Checked per Scan (3–20)
            </label>
            <input
              id="setting-max-links"
              type="number"
              min={3}
              max={20}
              value={maxLinks}
              onChange={(e) => setMaxLinks(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-sm font-mono bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] tabular-nums"
            />
            <p className="mt-1 text-xs text-[#7D5E4E]">
              Requests are paced in batches of 2 with 150ms delays.
            </p>
          </div>

          <div>
            <label
              htmlFor="setting-timeout"
              className="block text-xs font-medium text-[#3B2418] mb-1.5"
            >
              Request Timeout in Milliseconds (4000–15000)
            </label>
            <input
              id="setting-timeout"
              type="number"
              min={4000}
              max={15000}
              step={500}
              value={timeoutMs}
              onChange={(e) => setTimeoutMs(Number(e.target.value))}
              className="w-full px-3.5 py-2 text-sm font-mono bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] tabular-nums"
            />
            <p className="mt-1 text-xs text-[#7D5E4E]">
              Prevents hanging connections on slow origins.
            </p>
          </div>
        </div>

        <label className="flex items-start gap-2.5 text-xs text-[#3B2418] cursor-pointer">
          <input
            type="checkbox"
            checked={requireConfirm}
            onChange={(e) => setRequireConfirm(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-[#3B2418]"
          />
          <span>
            Require explicit website ownership / testing authorization checkbox before starting every scan
          </span>
        </label>

        <div className="flex items-center gap-4 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] disabled:opacity-50 rounded cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
          {savedToast && (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#15803D]">
              <Check className="w-3.5 h-3.5" />
              Saved changes
            </span>
          )}
        </div>
      </form>

      {/* Enforced SSRF & Passive Testing Safeguards */}
      <section className="bg-[#3B2418] text-[#F2E8DA] border border-[#2B1910] rounded-lg p-6 space-y-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#8EC5FF]" />
          <h2 className="text-sm font-semibold">
            Active Security Safeguards (Always Enforced)
          </h2>
        </div>
        <ul className="space-y-1.5 text-xs text-[#EADFCF] leading-relaxed">
          <li>• DNS-pinned SSRF protection blocks localhost, RFC1918 private IPs, link-local metadata endpoints (169.254.169.254), and IPv6 local ranges before every hop.</li>
          <li>• HTML is parsed statically with Cheerio — downloaded website scripts are never executed.</li>
          <li>• Strictly passive, non-destructive HTTP/TLS inspection capped at 2 MB per page and 5 redirects max.</li>
          <li>• Rate limited to 10 full scans per minute per session.</li>
        </ul>
      </section>

      {/* Modular Roadmap Notice */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-6 space-y-3">
        <h2 className="text-sm font-semibold text-[#3B2418]">
          Future-Ready Platform Architecture
        </h2>
        <p className="text-xs text-[#6E5041] leading-relaxed">
          LaunchGuard AI is structured into independent server modules so deeper developer integrations
          can be added cleanly without rewriting the core scanner. The following capabilities are planned
          for future releases and are not yet active in this MVP:
        </p>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs text-[#3B2418]">
          {plannedModules.map((mod) => (
            <li key={mod} className="flex items-center gap-2">
              <span className="text-[#8EC5FF] font-mono font-bold">—</span>
              <span>{mod}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};
