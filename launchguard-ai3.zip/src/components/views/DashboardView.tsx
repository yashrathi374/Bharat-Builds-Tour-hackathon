import React, { useState } from 'react';
import {
  Search,
  ShieldCheck,
  Gauge,
  FileSearch,
  Activity,
  Download,
  ArrowUpRight,
  AlertCircle,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import type {
  AuthUser,
  ScanHistoryItem,
  ScanReport,
  ScanStageProgress,
  ScannerSettings,
} from '../../types/scan';
import { ScoreRing } from '../ScoreRing';
import { ScannerProgress } from '../ScannerProgress';
import { FindingAccordion } from '../FindingAccordion';

export type NavSection =
  | 'dashboard'
  | 'scanner'
  | 'security'
  | 'performance'
  | 'seo'
  | 'ai'
  | 'history'
  | 'settings';

interface DashboardViewProps {
  user: AuthUser | null;
  urlInput: string;
  onUrlChange: (val: string) => void;
  authorized: boolean;
  onAuthorizedChange: (val: boolean) => void;
  settings: ScannerSettings;
  isScanning: boolean;
  scanError: string | null;
  scanStages: ScanStageProgress[];
  showProgress: boolean;
  activeReport: ScanReport | null;
  history: ScanHistoryItem[];
  onRunScan: (overrideUrl?: string) => void;
  onSelectHistoryItem: (id: string) => void;
  onNavigate: (section: NavSection) => void;
  onDownloadPdf: () => void;
}

const PUBLIC_TEST_TARGETS = [
  { label: 'example.com', url: 'https://example.com' },
  { label: 'developer.mozilla.org', url: 'https://developer.mozilla.org' },
  { label: 'news.ycombinator.com', url: 'https://news.ycombinator.com' },
];

function scoreTone(score: number): string {
  if (score >= 80) return 'text-[#15803D]';
  if (score >= 60) return 'text-[#B45309]';
  return 'text-[#B91C1C]';
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  urlInput,
  onUrlChange,
  authorized,
  onAuthorizedChange,
  settings,
  isScanning,
  scanError,
  scanStages,
  showProgress,
  activeReport,
  history,
  onRunScan,
  onSelectHistoryItem,
  onNavigate,
  onDownloadPdf,
}) => {
  const [findingFilter, setFindingFilter] = useState<'issues' | 'passed' | 'all'>('issues');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRunScan();
  };

  const openIssues = activeReport
    ? activeReport.allFindings.filter((f) => f.status !== 'pass')
    : [];
  const passedChecks = activeReport
    ? activeReport.allFindings.filter((f) => f.status === 'pass')
    : [];
  const displayedFindings =
    findingFilter === 'issues'
      ? openIssues
      : findingFilter === 'passed'
        ? passedChecks
        : activeReport?.allFindings ?? [];

  return (
    <div className="space-y-8">
      {/* Welcome & URL Scanner Focal Anchor */}
      <section className="space-y-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#3B2418]">
              {user ? `Welcome back, ${user.name.split(' ')[0]}` : 'Launch Readiness Command Center'}
            </h1>
            <p className="mt-1.5 text-sm text-[#6E5041]">
              Build with AI. Test with AI. Launch with Confidence. Run live HTTP, TLS, security header,
              performance, SEO, and internal link checks on any public site you are authorized to test.
            </p>
          </div>
          {activeReport && (
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                disabled={isScanning}
                onClick={() => onRunScan(activeReport.url)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-[#3B2418] bg-[#FAF5EE] hover:bg-[#E9DCC9] border border-[#D4C1AA] rounded transition-colors whitespace-nowrap disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                <span>Re-scan</span>
              </button>
              <button
                type="button"
                onClick={onDownloadPdf}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-[#F2E8DA] bg-[#3B2418] hover:bg-[#2C1A11] rounded transition-colors whitespace-nowrap cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-[#8EC5FF]" />
                <span>Download PDF Report</span>
              </button>
            </div>
          )}
        </div>

        {/* URL Input Bar */}
        <form
          onSubmit={handleFormSubmit}
          className="bg-[#FAF5EE] border border-[#3B2418]/25 rounded-lg overflow-hidden"
        >
          <div className="px-5 py-2.5 bg-[#3B2418] text-[#F2E8DA] flex items-center justify-between text-xs">
            <span className="font-medium">Live Website Inspector</span>
            <span className="font-mono text-[#8EC5FF]">SSRF-Protected · Passive Audit</span>
          </div>
          <div className="p-5 space-y-3.5">
            <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search
                className="w-4 h-4 text-[#7D5E4E] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <label htmlFor="website-url-input" className="sr-only">
                Website URL to scan
              </label>
              <input
                id="website-url-input"
                type="text"
                value={urlInput}
                onChange={(e) => onUrlChange(e.target.value)}
                placeholder="https://your-project.com"
                disabled={isScanning}
                className="w-full pl-10 pr-4 py-3 text-sm font-mono bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] placeholder-[#8C6D5C] focus:border-[#3B2418] focus:outline-none disabled:opacity-60"
              />
            </div>

            <button
              type="submit"
              disabled={isScanning || !urlInput.trim()}
              className="px-6 py-3 text-sm font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] disabled:opacity-50 rounded transition-colors whitespace-nowrap shrink-0 inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              {isScanning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Scanning...</span>
                </>
              ) : (
                <span>Scan Website</span>
              )}
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            {settings.requireAuthConfirmation ? (
              <label className="inline-flex items-center gap-2.5 text-xs text-[#4B3123] cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={authorized}
                  onChange={(e) => onAuthorizedChange(e.target.checked)}
                  className="w-4 h-4 rounded border-[#C6B39B] bg-[#F2E8DA] accent-[#3B2418]"
                />
                <span>
                  I confirm I own this website or have authorization to run passive non-destructive checks.
                </span>
              </label>
            ) : (
              <span className="text-xs text-[#6E5041]">
                Only scan websites you own or have permission to test. Private IPs and localhost are blocked.
              </span>
            )}

            <div className="flex flex-wrap items-center gap-2 text-xs text-[#6E5041]">
              <span>Public test targets:</span>
              {PUBLIC_TEST_TARGETS.map((target, idx) => (
                <React.Fragment key={target.url}>
                  {idx > 0 && <span aria-hidden="true">/</span>}
                  <button
                    type="button"
                    disabled={isScanning}
                    onClick={() => {
                      onUrlChange(target.url);
                      onAuthorizedChange(true);
                    }}
                    className="font-mono text-[#3B2418] underline decoration-[#8EC5FF] decoration-2 underline-offset-2 hover:text-[#1F120B] transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {target.label}
                  </button>
                </React.Fragment>
              ))}
            </div>
          </div>

          {scanError && (
            <div
              role="alert"
              className="flex items-start gap-2.5 px-3.5 py-2.5 text-xs text-[#991B1B] bg-[#FEE2E2] border border-[#FCA5A5] rounded"
            >
              <AlertCircle className="w-4 h-4 text-[#B91C1C] shrink-0 mt-0.5" />
              <span>{scanError}</span>
            </div>
          )}
          </div>
        </form>
      </section>

      {/* Live 6-Stage Scanning Animation */}
      {showProgress && (
        <ScannerProgress
          targetUrl={urlInput || activeReport?.url || ''}
          stages={scanStages}
          isScanning={isScanning}
        />
      )}

      {/* Empty State when no scan has been run yet */}
      {!activeReport && !isScanning && (
        <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg p-7">
          <h2 className="text-base font-semibold text-[#3B2418]">
            Ready for your first live website inspection
          </h2>
          <p className="mt-1.5 text-sm text-[#6E5041] max-w-2xl leading-relaxed">
            LaunchGuard AI never shows placeholder scores. Enter a live public URL above to execute a
            real six-stage passive check from our server and receive a transparent readiness score.
          </p>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 pt-5 border-t border-[#E4D6C4]">
            <div>
              <p className="text-xs font-semibold text-[#3B2418] inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-[#8EC5FF]" aria-hidden="true" />
                Security (35% weight)
              </p>
              <p className="mt-1 text-xs text-[#6E5041] leading-relaxed">
                TLS certificate trust &amp; expiry, HTTPS redirect, CSP, HSTS, X-Frame-Options, MIME sniffing, and server banners.
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-[#3B2418] inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-[#8EC5FF]" aria-hidden="true" />
                Performance (25% weight)
              </p>
              <p className="mt-1 text-xs text-[#6E5041] leading-relaxed">
                Real server response latency, HTML byte size, gzip/Brotli compression, image optimization, and third-party assets.
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-[#3B2418] inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-[#8EC5FF]" aria-hidden="true" />
                SEO Essentials (20% weight)
              </p>
              <p className="mt-1 text-xs text-[#6E5041] leading-relaxed">
                Document title, meta description, mobile viewport, primary H1 heading, OpenGraph preview tags, and image alt text.
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-[#3B2418] inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-sm bg-[#8EC5FF]" aria-hidden="true" />
                Availability &amp; Links (20% weight)
              </p>
              <p className="mt-1 text-xs text-[#6E5041] leading-relaxed">
                HTTP response health, redirect chain depth, and safe paced verification of internal page links.
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Active Scan Readiness Results */}
      {activeReport && (
        <>
          {/* Overall Launch Readiness Score + 4 Category Score Strip */}
          <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 bg-[#3B2418] text-[#F2E8DA] flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-2 min-w-0">
                <span className="font-mono text-[#F2E8DA] font-medium truncate max-w-md">
                  {activeReport.finalUrl}
                </span>
                <span aria-hidden="true" className="text-[#8C6D5C]">
                  ·
                </span>
                <span className="font-mono tabular-nums text-[#8EC5FF]">
                  HTTP {activeReport.availability.statusCode}
                </span>
                <span aria-hidden="true" className="text-[#8C6D5C]">
                  ·
                </span>
                <span className="font-mono tabular-nums text-[#D8C7B4]">
                  {activeReport.availability.responseTimeMs} ms
                </span>
              </div>
              <div className="font-mono tabular-nums text-[#D8C7B4]">
                Scanned {new Date(activeReport.scannedAt).toLocaleString()}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-[#E4D6C4]">
              {/* Overall Readiness Ring */}
              <div className="lg:col-span-4 p-6 flex items-center gap-6">
                <ScoreRing
                  score={activeReport.score.overall}
                  grade={activeReport.score.grade}
                />
                <div className="space-y-3 min-w-0">
                  <div>
                    <h2 className="text-sm font-semibold text-[#3B2418]">
                      Launch Readiness Score
                    </h2>
                    <p className="text-xs text-[#6E5041] mt-0.5">
                      Weighted across 4 live categories
                    </p>
                  </div>
                  <div className="space-y-1 text-xs font-mono tabular-nums">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-[#15803D] font-medium">Passed checks</span>
                      <span className="text-[#3B2418] font-semibold">
                        {activeReport.score.counts.passed}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-[#B45309] font-medium">Warnings</span>
                      <span className="text-[#3B2418] font-semibold">
                        {activeReport.score.counts.warnings}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-[#B91C1C] font-medium">Failed checks</span>
                      <span className="text-[#3B2418] font-semibold">
                        {activeReport.score.counts.failed}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4 Category Score Panels */}
              <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0 divide-[#E4D6C4]">
                <button
                  type="button"
                  onClick={() => onNavigate('security')}
                  className="p-5 text-left hover:bg-[#F2E8DA]/80 transition-colors flex flex-col justify-between cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs font-medium text-[#6E5041]">
                    <span>Security</span>
                    <ShieldCheck className="w-4 h-4 text-[#3B2418]" />
                  </div>
                  <div className="mt-4">
                    <p
                      className={`font-mono text-3xl font-semibold tabular-nums ${scoreTone(
                        activeReport.score.categories.security
                      )}`}
                    >
                      {activeReport.score.categories.security}
                    </p>
                    <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
                      35% weight · {activeReport.security.httpsEnabled ? 'HTTPS' : 'HTTP'}
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('performance')}
                  className="p-5 text-left hover:bg-[#F2E8DA]/80 transition-colors flex flex-col justify-between cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs font-medium text-[#6E5041]">
                    <span>Performance</span>
                    <Gauge className="w-4 h-4 text-[#3B2418]" />
                  </div>
                  <div className="mt-4">
                    <p
                      className={`font-mono text-3xl font-semibold tabular-nums ${scoreTone(
                        activeReport.score.categories.performance
                      )}`}
                    >
                      {activeReport.score.categories.performance}
                    </p>
                    <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
                      25% weight · {activeReport.performance.htmlSizeKb} KB
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('seo')}
                  className="p-5 text-left hover:bg-[#F2E8DA]/80 transition-colors flex flex-col justify-between cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs font-medium text-[#6E5041]">
                    <span>SEO</span>
                    <FileSearch className="w-4 h-4 text-[#3B2418]" />
                  </div>
                  <div className="mt-4">
                    <p
                      className={`font-mono text-3xl font-semibold tabular-nums ${scoreTone(
                        activeReport.score.categories.seo
                      )}`}
                    >
                      {activeReport.score.categories.seo}
                    </p>
                    <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
                      20% weight · {activeReport.seo.title ? 'Title set' : 'No title'}
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('scanner')}
                  className="p-5 text-left hover:bg-[#F2E8DA]/80 transition-colors flex flex-col justify-between cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs font-medium text-[#6E5041]">
                    <span>Availability</span>
                    <Activity className="w-4 h-4 text-[#3B2418]" />
                  </div>
                  <div className="mt-4">
                    <p
                      className={`font-mono text-3xl font-semibold tabular-nums ${scoreTone(
                        activeReport.score.categories.availability
                      )}`}
                    >
                      {activeReport.score.categories.availability}
                    </p>
                    <p className="mt-1 text-xs text-[#7D5E4E] font-mono tabular-nums">
                      20% weight · {activeReport.links.brokenCount} broken link(s)
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Transparent Score Deductions Strip */}
            {activeReport.score.deductions.length > 0 && (
              <div className="px-5 py-3 bg-[#F2E8DA]/70 border-t border-[#E4D6C4] flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs">
                <span className="font-semibold text-[#3B2418]">Score deductions:</span>
                {activeReport.score.deductions.slice(0, 6).map((d, i) => (
                  <span key={i} className="font-mono text-[#6E5041] tabular-nums">
                    <span className="text-[#B91C1C] font-medium">-{d.points}</span>{' '}
                    <span className="capitalize">({d.category})</span> {d.reason}
                  </span>
                ))}
              </div>
            )}
          </section>

          {/* AI Website Analyst Summary & Recommendations Preview */}
          <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4D6C4] flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold text-[#3B2418]">
                  AI Website Analyst Summary
                </h2>
                <p className="text-xs text-[#6E5041] mt-0.5">
                  Plain-language interpretation grounded strictly in your measured scan output
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('ai')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] rounded transition-colors whitespace-nowrap cursor-pointer"
              >
                <span>Open full AI review</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-5">
              {activeReport.ai.status === 'completed' ? (
                <div className="space-y-4">
                  <p className="text-sm text-[#3B2418] leading-relaxed max-w-4xl">
                    {activeReport.ai.executiveSummary}
                  </p>
                  {activeReport.ai.launchVerdict && (
                    <p className="text-sm font-semibold text-[#3B2418] bg-[#8EC5FF]/25 border border-[#8EC5FF]/60 rounded px-3.5 py-2.5">
                      {activeReport.ai.launchVerdict}
                    </p>
                  )}
                  {activeReport.ai.topStrengths && activeReport.ai.topStrengths.length > 0 && (
                    <div className="pt-3 border-t border-[#E4D6C4]">
                      <p className="text-xs font-medium text-[#6E5041] mb-2">
                        Verified strengths from this scan
                      </p>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-[#3B2418]">
                        {activeReport.ai.topStrengths.map((s, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-[#15803D] font-mono font-bold">+</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-sm text-[#B45309] leading-relaxed">
                  {activeReport.ai.errorMessage ||
                    'AI Website Analyst did not return recommendations for this scan.'}
                </div>
              )}
            </div>
          </section>

          {/* Detected Issues & Passed Checks with Beginner-Friendly Fix Guides */}
          <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E4D6C4] flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold text-[#3B2418]">
                  Detected Issues &amp; Fix Guides
                </h2>
                <p className="text-xs text-[#6E5041] mt-0.5">
                  Expand any item for step-by-step instructions and verification tips
                </p>
              </div>

              <div className="flex items-center gap-1 p-1 bg-[#F2E8DA] border border-[#D4C1AA] rounded">
                {(
                  [
                    { id: 'issues', label: `Issues (${openIssues.length})` },
                    { id: 'passed', label: `Passed (${passedChecks.length})` },
                    { id: 'all', label: `All (${activeReport.allFindings.length})` },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFindingFilter(tab.id)}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                      findingFilter === tab.id
                        ? 'bg-[#8EC5FF] text-[#3B2418] font-semibold'
                        : 'text-[#6E5041] hover:text-[#3B2418]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <FindingAccordion
              findings={displayedFindings}
              defaultOpenFirst={findingFilter !== 'passed'}
              emptyMessage={
                findingFilter === 'issues'
                  ? 'All automated checks passed with zero detected warnings or failures.'
                  : 'No findings match this filter.'
              }
            />
          </section>
        </>
      )}

      {/* Recent Scan History */}
      <section className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E4D6C4] flex items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-[#3B2418]">Recent Scan History</h2>
            <p className="text-xs text-[#6E5041] mt-0.5">
              Saved automatically in your workspace database
            </p>
          </div>
          {history.length > 0 && (
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="text-xs font-semibold text-[#3B2418] underline decoration-[#8EC5FF] decoration-2 underline-offset-2 whitespace-nowrap cursor-pointer"
            >
              View all ({history.length})
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <div className="px-5 py-8 text-sm text-[#6E5041] text-center">
            No scans recorded yet. Enter a website URL above to run your first live audit.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2B1910] bg-[#3B2418] text-xs text-[#F2E8DA]">
                  <th className="py-2.5 px-5 font-semibold">Website</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Readiness</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Security</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Perf</th>
                  <th className="py-2.5 px-4 font-semibold text-right">SEO</th>
                  <th className="py-2.5 px-4 font-semibold text-right">Status</th>
                  <th className="py-2.5 px-5 font-semibold text-right">Scanned</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E4D6C4] text-sm">
                {history.slice(0, 6).map((item) => {
                  const isActive = activeReport?.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => onSelectHistoryItem(item.id)}
                      className={`cursor-pointer transition-colors ${
                        isActive ? 'bg-[#8EC5FF]/25' : 'hover:bg-[#F2E8DA]/70'
                      }`}
                    >
                      <td className="py-3 px-5 font-mono text-xs text-[#3B2418] font-medium max-w-xs truncate">
                        {item.finalUrl}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-mono text-xs font-semibold tabular-nums ${scoreTone(
                          item.overallScore
                        )}`}
                      >
                        {item.overallScore}/100
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-[#4B3123] tabular-nums">
                        {item.securityScore}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-[#4B3123] tabular-nums">
                        {item.performanceScore}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-[#4B3123] tabular-nums">
                        {item.seoScore}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-[#6E5041] tabular-nums">
                        {item.statusCode} · {item.responseTimeMs}ms
                      </td>
                      <td className="py-3 px-5 text-right font-mono text-xs text-[#7D5E4E] tabular-nums whitespace-nowrap">
                        {new Date(item.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
