import React from 'react';
import { CheckCircle2, AlertTriangle, Loader2, Circle, XCircle } from 'lucide-react';
import type { ScanStageProgress } from '../types/scan';

interface ScannerProgressProps {
  targetUrl: string;
  stages: ScanStageProgress[];
  isScanning: boolean;
}

export const ScannerProgress: React.FC<ScannerProgressProps> = ({
  targetUrl,
  stages,
  isScanning,
}) => {
  const completedCount = stages.filter(
    (s) => s.status === 'completed' || s.status === 'warning'
  ).length;
  const pct = Math.round((completedCount / stages.length) * 100);

  return (
    <section
      aria-live="polite"
      className="bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden"
    >
      <div className="px-5 py-4 bg-[#3B2418] text-[#F2E8DA] flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-[#F2E8DA]">
            {isScanning ? 'Live Website Inspection in Progress' : 'Inspection Sequence Complete'}
          </h2>
          <p className="text-xs text-[#D8C7B4] font-mono mt-0.5 truncate max-w-xl">
            {targetUrl}
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono tabular-nums text-[#8EC5FF]">
          <span>
            {completedCount} / {stages.length} stages
          </span>
          <span aria-hidden="true" className="text-[#8C6D5C]">
            /
          </span>
          <span>{pct}%</span>
        </div>
      </div>

      {/* Linear progress bar in Baby Blue */}
      <div className="h-1.5 bg-[#E6D9C7] w-full overflow-hidden">
        <div
          className="h-full bg-[#8EC5FF] transition-transform duration-300 ease-out origin-left"
          style={{ transform: `scaleX(${Math.max(0.04, pct / 100)})` }}
        />
      </div>

      <ol className="divide-y divide-[#E4D6C4]">
        {stages.map((stage, index) => {
          const isRunning = stage.status === 'running';
          return (
            <li
              key={stage.id}
              className={`px-5 py-3 flex items-center justify-between gap-4 transition-colors ${
                isRunning ? 'bg-[#8EC5FF]/20' : ''
              }`}
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <span className="font-mono text-xs text-[#7D5E4E] tabular-nums w-5 shrink-0">
                  0{index + 1}
                </span>
                <span className="shrink-0" aria-hidden="true">
                  {stage.status === 'running' && (
                    <Loader2 className="w-4 h-4 text-[#3B2418] animate-spin" />
                  )}
                  {stage.status === 'completed' && (
                    <CheckCircle2 className="w-4 h-4 text-[#15803D]" />
                  )}
                  {stage.status === 'warning' && (
                    <AlertTriangle className="w-4 h-4 text-[#B45309]" />
                  )}
                  {stage.status === 'error' && (
                    <XCircle className="w-4 h-4 text-[#B91C1C]" />
                  )}
                  {stage.status === 'pending' && (
                    <Circle className="w-4 h-4 text-[#C6B39B]" />
                  )}
                </span>
                <div className="min-w-0">
                  <p
                    className={`text-sm ${
                      stage.status === 'pending'
                        ? 'text-[#8B6F5F]'
                        : isRunning
                          ? 'text-[#3B2418] font-semibold'
                          : 'text-[#3B2418]'
                    }`}
                  >
                    {stage.label}
                  </p>
                  {stage.detail && (
                    <p className="text-xs text-[#6E5041] truncate mt-0.5">{stage.detail}</p>
                  )}
                </div>
              </div>

              <div className="shrink-0 text-right font-mono text-xs tabular-nums">
                {stage.durationMs !== undefined ? (
                  <span className="text-[#6E5041]">{stage.durationMs} ms</span>
                ) : isRunning ? (
                  <span className="text-[#3B2418] font-semibold">Running</span>
                ) : (
                  <span className="text-[#9A8071]">Queued</span>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
};
