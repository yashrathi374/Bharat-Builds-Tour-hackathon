import React, { useState } from 'react';
import { X, Loader2 } from 'lucide-react';
import { api } from '../services/api';
import type { AuthUser } from '../types/scan';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthenticated: (user: AuthUser) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthenticated,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const result =
        mode === 'register'
          ? await api.register({ name, email, password })
          : await api.login({ email, password });
      onAuthenticated(result.user);
      onClose();
      setName('');
      setEmail('');
      setPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#3B2418]/65 px-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-md bg-[#FAF5EE] border border-[#D9C7B2] rounded-lg overflow-hidden">
        <div className="px-6 py-4 bg-[#3B2418] text-[#F2E8DA] flex items-center justify-between">
          <h2 id="auth-modal-title" className="text-base font-semibold text-[#F2E8DA]">
            {mode === 'register' ? 'Create LaunchGuard Account' : 'Sign In to LaunchGuard AI'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 text-[#D8C7B4] hover:text-[#F2E8DA] rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-[#6E5041] leading-relaxed">
            {mode === 'register'
              ? 'Save your website scan history and custom scanner settings to a personal account. Existing scans from this session are preserved automatically.'
              : 'Sign in to access your saved website audits and readiness history.'}
          </p>

          {error && (
            <div className="px-3.5 py-2.5 text-xs text-[#991B1B] bg-[#FEE2E2] border border-[#FCA5A5] rounded">
              {error}
            </div>
          )}

          {mode === 'register' && (
            <div>
              <label
                htmlFor="auth-name"
                className="block text-xs font-medium text-[#3B2418] mb-1.5"
              >
                Full name
              </label>
              <input
                id="auth-name"
                type="text"
                required
                minLength={2}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Alex Rivera"
                className="w-full px-3.5 py-2.5 text-sm bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] placeholder-[#8C6D5C] focus:border-[#3B2418] focus:outline-none"
              />
            </div>
          )}

          <div>
            <label
              htmlFor="auth-email"
              className="block text-xs font-medium text-[#3B2418] mb-1.5"
            >
              Email address
            </label>
            <input
              id="auth-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="w-full px-3.5 py-2.5 text-sm bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] placeholder-[#8C6D5C] focus:border-[#3B2418] focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="auth-password"
              className="block text-xs font-medium text-[#3B2418] mb-1.5"
            >
              Password
            </label>
            <input
              id="auth-password"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 8 characters"
              className="w-full px-3.5 py-2.5 text-sm bg-[#F2E8DA] border border-[#D4C1AA] rounded text-[#3B2418] placeholder-[#8C6D5C] focus:border-[#3B2418] focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 text-sm font-semibold text-[#3B2418] bg-[#8EC5FF] hover:bg-[#77B7FA] border border-[#6BB0F7] disabled:opacity-60 rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{mode === 'register' ? 'Create Account' : 'Sign In'}</span>
          </button>

          <div className="pt-2 text-center text-xs text-[#6E5041]">
            {mode === 'register' ? (
              <>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                  }}
                  className="text-[#3B2418] underline decoration-[#8EC5FF] decoration-2 underline-offset-2 font-semibold cursor-pointer"
                >
                  Sign in
                </button>
              </>
            ) : (
              <>
                Need an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setError(null);
                  }}
                  className="text-[#3B2418] underline decoration-[#8EC5FF] decoration-2 underline-offset-2 font-semibold cursor-pointer"
                >
                  Create one
                </button>
              </>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
