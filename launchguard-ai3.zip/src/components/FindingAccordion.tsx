import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Check,
} from 'lucide-react';
import type { AuditFinding } from '../types/scan';

interface FindingAccordionProps {
  findings: AuditFinding[];
  emptyMessage?: string;
  defaultOpenFirst?: boolean;
}

export function severityLabel(severity: AuditFinding['severity']): {
  text: string;
  className: string;
} {
  switch (severity) {
    case 'critical':
      return { text: 'Critical', className: 'text-[#B91C1C]' };
    case 'high':
      return { text: 'High', className: 'text-[#C2410C]' };
    case 'medium':
      return { text: 'Warning', className: 'text-[#B45309]' };
    case 'low':
      return { text: 'Advisory', className: 'text-[#3B7BBF]' };
    case 'pass':
      return { text: 'Passed', className: 'text-[#15803D]' };
    default:
      return { text: 'Info', className: 'text-[#6E5041]' };
  }
}

export const FindingAccordion: React.FC<FindingAccordionProps> = ({
  findings,
  emptyMessage = 'No findings in this category.',
  defaultOpenFirst = false,
}) => {
  const [openIds, setOpenIds] = useState<Record<string, boolean>>(() => {
    if (defaultOpenFirst && findings.length > 0 && findings[0].status !== 'pass') {
      return { [findings[0].id]: true };
    }
    return {};
  });
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggle = (id: string) => {
    setOpenIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId((curr) => (curr === id ? null : curr)), 1600);
    } catch {
      // Clipboard unavailable in restricted iframe
    }
  };

  if (findings.length === 0) {
    return (
      <div className="px-5 py-8 text-sm text-[#6E5041] text-center">{emptyMessage}</div>
    );
  }

  return (
    <div className="divide-y divide-[#E4D6C4]">
      {findings.map((finding) => {
        const isOpen = Boolean(openIds[finding.id]);
        const sev = severityLabel(finding.severity);
        const StatusIcon =
          finding.status === 'pass'
            ? CheckCircle2
            : finding.status === 'warning'
              ? AlertTriangle
              : XCircle;
        const iconColor =
          finding.status === 'pass'
            ? 'text-[#15803D]'
            : finding.status === 'warning'
              ? 'text-[#B45309]'
              : 'text-[#B91C1C]';

        return (
          <div key={finding.id} className="bg-[#FAF5EE]">
            <button
              type="button"
              onClick={() => toggle(finding.id)}
              aria-expanded={isOpen}
              className="w-full text-left px-5 py-3.5 flex items-start justify-between gap-4 hover:bg-[#F2E8DA]/80 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-3 min-w-0">
                <StatusIcon className={`w-4 h-4 mt-0.5 shrink-0 ${iconColor}`} aria-hidden="true" />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5">
                    <span className="text-sm font-medium text-[#3B2418]">
                      {finding.title}
                    </span>
                    <span aria-hidden="true" className="text-[#C8B59E] text-xs">
                      ·
                    </span>
                    <span className={`text-xs font-semibold ${sev.className}`}>
                      {sev.text}
                    </span>
                    <span aria-hidden="true" className="text-[#C8B59E] text-xs">
                      ·
                    </span>
                    <span className="text-xs text-[#7D5E4E] capitalize">
                      {finding.category}
                    </span>
                  </div>
                  <p className="text-xs text-[#6E5041] mt-1 font-mono truncate max-w-2xl">
                    Observed: {finding.observedValue}
                  </p>
                </div>
              </div>

              <span className="shrink-0 flex items-center gap-1.5 text-xs font-medium text-[#3B2418] mt-0.5 whitespace-nowrap">
                <span>
                  {finding.fixGuide ? (isOpen ? 'Hide guide' : 'Fix guide') : isOpen ? 'Less' : 'Details'}
                </span>
                {isOpen ? (
                  <ChevronDown className="w-4 h-4 text-[#6E5041]" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-[#6E5041]" />
                )}
              </span>
            </button>

            {isOpen && (
              <div className="px-5 pb-5 pt-3 bg-[#F2E8DA]/75 border-t border-[#E4D6C4] space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs font-medium text-[#6E5041] mb-1">Explanation</p>
                    <p className="text-[#3B2418] leading-relaxed">{finding.explanation}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-[#6E5041] mb-1">Recommended action</p>
                    <p className="text-[#3B2418] leading-relaxed">{finding.recommendation}</p>
                  </div>
                </div>

                {finding.fixGuide && (
                  <div className="pt-3 border-t border-[#DFD0BE] space-y-4">
                    <h4 className="text-sm font-semibold text-[#3B2418] inline-flex items-center gap-2">
                      <span className="w-2 h-2 rounded-sm bg-[#8EC5FF]" aria-hidden="true" />
                      Beginner-Friendly Fix Guide
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">
                          What is the problem?
                        </p>
                        <p className="text-[#3B2418] leading-relaxed">
                          {finding.fixGuide.whatIsTheProblem}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">
                          Why does it matter?
                        </p>
                        <p className="text-[#3B2418] leading-relaxed">
                          {finding.fixGuide.whyItMatters}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-[#6E5041] mb-1">
                          Potential risk
                        </p>
                        <p className="text-[#3B2418] leading-relaxed">
                          {finding.fixGuide.potentialRisk}
                        </p>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs font-medium text-[#6E5041] mb-1">How to fix it</p>
                      <p className="text-sm text-[#3B2418] leading-relaxed mb-3">
                        {finding.fixGuide.howToFix}
                      </p>
                      <ol className="space-y-2 text-sm text-[#4B3123]">
                        {finding.fixGuide.stepByStep.map((step, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            <span className="font-mono text-xs font-semibold text-[#3B2418] bg-[#8EC5FF] px-1.5 py-0.5 rounded tabular-nums shrink-0">
                              {i + 1}
                            </span>
                            <span className="leading-relaxed">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    {finding.fixGuide.codeSnippet && (
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <p className="text-xs font-medium text-[#6E5041]">
                            Example configuration
                          </p>
                          <button
                            type="button"
                            onClick={() =>
                              handleCopy(finding.id, finding.fixGuide!.codeSnippet!)
                            }
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-[#3B2418] bg-[#8EC5FF] hover:bg-[#75B8FF] rounded transition-colors cursor-pointer"
                          >
                            {copiedId === finding.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-[#15803D]" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy snippet</span>
                              </>
                            )}
                          </button>
                        </div>
                        <pre className="bg-[#3B2418] border border-[#2B1910] rounded px-3.5 py-2.5 text-xs font-mono text-[#F2E8DA] overflow-x-auto">
                          {finding.fixGuide.codeSnippet}
                        </pre>
                      </div>
                    )}

                    <div className="pt-2 border-t border-[#DFD0BE]">
                      <p className="text-xs font-medium text-[#6E5041] mb-1">
                        How to verify the fix
                      </p>
                      <p className="text-sm text-[#3B2418] leading-relaxed">
                        {finding.fixGuide.howToVerify}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
