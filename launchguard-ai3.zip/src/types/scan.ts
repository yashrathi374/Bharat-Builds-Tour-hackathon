export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info' | 'pass';

export type ScanStageId =
  | 'availability'
  | 'security'
  | 'performance'
  | 'seo'
  | 'links'
  | 'ai';

export type ScanStageStatus = 'pending' | 'running' | 'completed' | 'warning' | 'error';

export interface ScanStageProgress {
  id: ScanStageId;
  label: string;
  status: ScanStageStatus;
  detail?: string;
  durationMs?: number;
}

export interface RedirectHop {
  from: string;
  to: string;
  statusCode: number;
  durationMs: number;
}

export interface AvailabilityResult {
  requestedUrl: string;
  finalUrl: string;
  reachable: boolean;
  statusCode: number;
  statusText: string;
  responseTimeMs: number;
  isHttps: boolean;
  httpToHttpsRedirect: boolean | null;
  redirectChain: RedirectHop[];
  resolvedIp: string;
  contentType: string;
  errorMessage?: string;
}

export interface TlsCertificateInfo {
  available: boolean;
  valid: boolean;
  authorizationError?: string;
  subject?: string;
  issuer?: string;
  validFrom?: string;
  validTo?: string;
  daysRemaining?: number;
  protocol?: string;
  cipher?: string;
  error?: string;
}

export interface FixGuide {
  whatIsTheProblem: string;
  whyItMatters: string;
  potentialRisk: string;
  howToFix: string;
  stepByStep: string[];
  howToVerify: string;
  codeSnippet?: string;
}

export interface AuditFinding {
  id: string;
  category: 'security' | 'performance' | 'seo' | 'availability' | 'links';
  title: string;
  severity: Severity;
  status: 'pass' | 'warning' | 'fail';
  observedValue: string;
  expectedValue?: string;
  explanation: string;
  recommendation: string;
  fixGuide?: FixGuide;
}

export interface SecurityResult {
  httpsEnabled: boolean;
  tls: TlsCertificateInfo;
  headers: Record<string, string | null>;
  serverExposure: {
    serverHeader: string | null;
    poweredByHeader: string | null;
    exposed: boolean;
  };
  findings: AuditFinding[];
  scopeDisclaimer: string;
}

export interface PerformanceResult {
  responseTimeMs: number;
  htmlSizeBytes: number;
  htmlSizeKb: number;
  contentEncoding: string | null;
  cacheControl: string | null;
  imageCount: number;
  imagesWithoutLazyLoading: number;
  imagesWithoutDimensions: number;
  externalScriptCount: number;
  externalStylesheetCount: number;
  totalExternalResources: number;
  externalDomains: string[];
  inlineScriptCount: number;
  findings: AuditFinding[];
}

export interface SeoResult {
  title: string | null;
  titleLength: number;
  metaDescription: string | null;
  metaDescriptionLength: number;
  canonicalUrl: string | null;
  h1Count: number;
  h1Texts: string[];
  htmlLang: string | null;
  viewportMeta: string | null;
  ogTitle: string | null;
  ogDescription: string | null;
  ogImage: string | null;
  robotsMeta: string | null;
  totalImages: number;
  imagesMissingAlt: number;
  findings: AuditFinding[];
}

export interface CheckedLink {
  url: string;
  anchorText: string;
  statusCode: number | null;
  ok: boolean;
  responseTimeMs: number;
  error?: string;
}

export interface LinkCheckSummary {
  totalExtractedLinks: number;
  internalLinksFound: number;
  checkedCount: number;
  maxCheckedLimit: number;
  brokenCount: number;
  healthyCount: number;
  links: CheckedLink[];
  findings: AuditFinding[];
}

export interface ScoreDeduction {
  category: 'security' | 'performance' | 'seo' | 'availability';
  reason: string;
  points: number;
}

export interface ReadinessScore {
  overall: number;
  grade: 'Launch Ready' | 'Needs Attention' | 'Action Required';
  weights: {
    security: number;
    performance: number;
    seo: number;
    availability: number;
  };
  categories: {
    security: number;
    performance: number;
    seo: number;
    availability: number;
  };
  counts: {
    passed: number;
    warnings: number;
    failed: number;
  };
  deductions: ScoreDeduction[];
}

export interface AIGlossaryTerm {
  term: string;
  simpleExplanation: string;
}

export interface AIPrioritizedFix {
  findingTitle: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  plainEnglishExplanation: string;
  whyItMatters: string;
  potentialRisk: string;
  stepByStepFix: string[];
  howToVerify: string;
}

export interface AILaunchChecklistItem {
  task: string;
  category: 'Security' | 'Performance' | 'SEO' | 'Availability' | 'Links';
  priority: 'Before Launch' | 'Recommended' | 'Monitor';
  completed: boolean;
}

export interface AIAnalysisResult {
  status: 'completed' | 'error' | 'unavailable';
  model?: string;
  generatedAt?: string;
  errorMessage?: string;
  executiveSummary?: string;
  launchVerdict?: string;
  topStrengths?: string[];
  prioritizedFixes?: AIPrioritizedFix[];
  glossary?: AIGlossaryTerm[];
  launchChecklist?: AILaunchChecklistItem[];
}

export interface ScanReport {
  id: string;
  url: string;
  finalUrl: string;
  scannedAt: string;
  totalDurationMs: number;
  availability: AvailabilityResult;
  security: SecurityResult;
  performance: PerformanceResult;
  seo: SeoResult;
  links: LinkCheckSummary;
  score: ReadinessScore;
  allFindings: AuditFinding[];
  ai: AIAnalysisResult;
}

export interface ScanHistoryItem {
  id: string;
  url: string;
  finalUrl: string;
  overallScore: number;
  securityScore: number;
  performanceScore: number;
  seoScore: number;
  availabilityScore: number;
  passedCount: number;
  warningCount: number;
  failedCount: number;
  statusCode: number;
  responseTimeMs: number;
  createdAt: string;
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface ScannerSettings {
  maxLinksToCheck: number;
  requestTimeoutMs: number;
  requireAuthConfirmation: boolean;
}
