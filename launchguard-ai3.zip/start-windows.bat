@echo off
title LaunchGuard AI
echo ===================================================
echo   Starting LaunchGuard AI on Windows
echo ===================================================
echo.

if not exist node_modules (
  echo [1/2] Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo Error during npm install. Make sure Node.js is installed.
    pause
    exit /b %errorlevel%
  )
)

echo.
echo [2/2] Starting server at http://localhost:3000...
call npm run dev
pause
