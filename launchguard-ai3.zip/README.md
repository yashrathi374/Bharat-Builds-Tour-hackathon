# LaunchGuard AI

Real-time website testing, security configuration inspection, performance & SEO analysis, broken link verification, and AI-guided launch readiness reports.

---

### Custom Palette
- **Cream (`#F2E8DA`) ~65% to 70%**: Main body canvas, card backgrounds (`#FAF5EE`), borders (`#D9C7B2`, `#E4D6C4`), input fields.
- **Espresso Brown (`#3B2418`) ~20% to 25%**: Desktop sidebar, card headers, table header banners, dark text, dark buttons.
- **Baby Blue (`#8EC5FF`) ~10%**: Interactive action buttons, active tabs, progress bar, badges.

---

## Quick Start on Windows

### Option 1: One-Click Launch (Easiest)
Simply double-click **`start-windows.bat`** in this folder. It will install dependencies and start the app automatically.

### Option 2: Command Line (cmd or PowerShell)
1. Open PowerShell or Command Prompt in this folder:
   ```cmd
   npm install
   ```
2. Start the development server:
   ```cmd
   npm run dev
   ```
3. Open **`http://localhost:3000`** in your browser.

---

### Requirements
- **Node.js**: v18 or later (Recommended: Node v20 or v22+)
- Works directly on Windows with **no C++ compilers or Visual Studio build tools required**!
