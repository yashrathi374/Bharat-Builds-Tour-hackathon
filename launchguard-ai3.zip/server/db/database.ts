import fs from 'fs';
import path from 'path';
import type {
  AIAnalysisResult,
  AuthUser,
  ScanHistoryItem,
  ScanReport,
  ScannerSettings,
} from '../../src/types/scan.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'launchguard.db');
const JSON_BACKUP_PATH = path.join(DATA_DIR, 'launchguard-fallback.json');

// Interface abstraction for database queries
interface DbStatement {
  run(...params: unknown[]): { changes: number; lastInsertRowid?: number | bigint };
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
}

interface DbInstance {
  exec(sql: string): void;
  prepare(sql: string): DbStatement;
}

let db: DbInstance;

// Try initializing node:sqlite (native in Node.js 22+, zero build tools required on Windows)
try {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { DatabaseSync } = await import('node:sqlite');
  const nativeDb = new DatabaseSync(DB_PATH);
  nativeDb.exec('PRAGMA journal_mode = WAL;');
  nativeDb.exec('PRAGMA foreign_keys = ON;');
  db = nativeDb;
} catch {
  // Fallback 1: try better-sqlite3 if installed
  try {
    // @ts-expect-error dynamic import
    const BetterSqlite3 = (await import('better-sqlite3')).default;
    const bDb = new BetterSqlite3(DB_PATH);
    bDb.pragma('journal_mode = WAL');
    bDb.pragma('foreign_keys = ON');
    db = bDb;
  } catch {
    // Fallback 2: Pure-JS JSON storage (guarantees LaunchGuard runs on ANY Windows machine without errors)
    db = createJsonFallbackDb(JSON_BACKUP_PATH);
  }
}

// Create database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS scans (
    id TEXT PRIMARY KEY,
    owner_key TEXT NOT NULL,
    user_id TEXT,
    url TEXT NOT NULL,
    final_url TEXT NOT NULL,
    overall_score INTEGER NOT NULL,
    security_score INTEGER NOT NULL,
    performance_score INTEGER NOT NULL,
    seo_score INTEGER NOT NULL,
    availability_score INTEGER NOT NULL,
    passed_count INTEGER NOT NULL,
    warning_count INTEGER NOT NULL,
    failed_count INTEGER NOT NULL,
    status_code INTEGER NOT NULL,
    response_time_ms INTEGER NOT NULL,
    report_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE INDEX IF NOT EXISTS idx_scans_owner_created ON scans(owner_key, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_scans_user_created ON scans(user_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS settings (
    owner_key TEXT PRIMARY KEY,
    max_links_to_check INTEGER NOT NULL DEFAULT 12,
    request_timeout_ms INTEGER NOT NULL DEFAULT 10000,
    require_auth_confirmation INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL
  );
`);

export interface DbUserRow {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  password_salt: string;
  created_at: string;
}

export function createUser(
  id: string,
  email: string,
  name: string,
  passwordHash: string,
  passwordSalt: string
): AuthUser {
  const createdAt = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (id, email, name, password_hash, password_salt, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(id, email.toLowerCase().trim(), name.trim(), passwordHash, passwordSalt, createdAt);
  return { id, email: email.toLowerCase().trim(), name: name.trim(), createdAt };
}

export function findUserByEmail(email: string): DbUserRow | undefined {
  return db
    .prepare(`SELECT * FROM users WHERE email = ?`)
    .get(email.toLowerCase().trim()) as DbUserRow | undefined;
}

export function findUserById(id: string): AuthUser | undefined {
  const row = db
    .prepare(`SELECT id, email, name, created_at FROM users WHERE id = ?`)
    .get(id) as { id: string; email: string; name: string; created_at: string } | undefined;
  if (!row) return undefined;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    createdAt: row.created_at,
  };
}

export function createSession(token: string, userId: string, ttlDays = 14): void {
  const now = new Date();
  const expires = new Date(now.getTime() + ttlDays * 24 * 60 * 60 * 1000);
  db.prepare(
    `INSERT INTO sessions (token, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)`
  ).run(token, userId, expires.toISOString(), now.toISOString());
}

export function getUserBySessionToken(token: string): AuthUser | undefined {
  const row = db
    .prepare(
      `SELECT u.id, u.email, u.name, u.created_at, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = ?`
    )
    .get(token) as
    | { id: string; email: string; name: string; created_at: string; expires_at: string }
    | undefined;

  if (!row) return undefined;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    deleteSession(token);
    return undefined;
  }
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    createdAt: row.created_at,
  };
}

export function deleteSession(token: string): void {
  db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
}

export function claimGuestScansForUser(guestOwnerKey: string, userId: string): void {
  const userOwnerKey = `user:${userId}`;
  db.prepare(
    `UPDATE scans SET owner_key = ?, user_id = ? WHERE owner_key = ?`
  ).run(userOwnerKey, userId, guestOwnerKey);
}

export function saveScanReport(
  ownerKey: string,
  userId: string | null,
  report: ScanReport
): void {
  db.prepare(
    `INSERT INTO scans (
      id, owner_key, user_id, url, final_url,
      overall_score, security_score, performance_score, seo_score, availability_score,
      passed_count, warning_count, failed_count,
      status_code, response_time_ms, report_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    report.id,
    ownerKey,
    userId,
    report.url,
    report.finalUrl,
    report.score.overall,
    report.score.categories.security,
    report.score.categories.performance,
    report.score.categories.seo,
    report.score.categories.availability,
    report.score.counts.passed,
    report.score.counts.warnings,
    report.score.counts.failed,
    report.availability.statusCode,
    report.availability.responseTimeMs,
    JSON.stringify(report),
    report.scannedAt
  );
}

export function listScansForOwner(ownerKey: string, limit = 50): ScanHistoryItem[] {
  const rows = db
    .prepare(
      `SELECT
        id, url, final_url, overall_score, security_score, performance_score,
        seo_score, availability_score, passed_count, warning_count, failed_count,
        status_code, response_time_ms, created_at
       FROM scans
       WHERE owner_key = ?
       ORDER BY created_at DESC
       LIMIT ?`
    )
    .all(ownerKey, limit) as Array<{
    id: string;
    url: string;
    final_url: string;
    overall_score: number;
    security_score: number;
    performance_score: number;
    seo_score: number;
    availability_score: number;
    passed_count: number;
    warning_count: number;
    failed_count: number;
    status_code: number;
    response_time_ms: number;
    created_at: string;
  }>;

  return rows.map((r) => ({
    id: r.id,
    url: r.url,
    finalUrl: r.final_url,
    overallScore: r.overall_score,
    securityScore: r.security_score,
    performanceScore: r.performance_score,
    seoScore: r.seo_score,
    availabilityScore: r.availability_score,
    passedCount: r.passed_count,
    warningCount: r.warning_count,
    failedCount: r.failed_count,
    statusCode: r.status_code,
    responseTimeMs: r.response_time_ms,
    createdAt: r.created_at,
  }));
}

export function getScanReportById(id: string, ownerKey: string): ScanReport | undefined {
  const row = db
    .prepare(`SELECT report_json FROM scans WHERE id = ? AND owner_key = ?`)
    .get(id, ownerKey) as { report_json: string } | undefined;
  if (!row) return undefined;
  return JSON.parse(row.report_json) as ScanReport;
}

export function updateScanAIAnalysis(
  id: string,
  ownerKey: string,
  ai: AIAnalysisResult
): ScanReport | undefined {
  const report = getScanReportById(id, ownerKey);
  if (!report) return undefined;
  report.ai = ai;
  db.prepare(`UPDATE scans SET report_json = ? WHERE id = ? AND owner_key = ?`).run(
    JSON.stringify(report),
    id,
    ownerKey
  );
  return report;
}

export function deleteScanById(id: string, ownerKey: string): boolean {
  const info = db
    .prepare(`DELETE FROM scans WHERE id = ? AND owner_key = ?`)
    .run(id, ownerKey);
  return info.changes > 0;
}

export function getSettingsForOwner(ownerKey: string): ScannerSettings {
  const row = db
    .prepare(
      `SELECT max_links_to_check, request_timeout_ms, require_auth_confirmation
       FROM settings WHERE owner_key = ?`
    )
    .get(ownerKey) as
    | {
        max_links_to_check: number;
        request_timeout_ms: number;
        require_auth_confirmation: number;
      }
    | undefined;

  if (!row) {
    return {
      maxLinksToCheck: 12,
      requestTimeoutMs: 10000,
      requireAuthConfirmation: true,
    };
  }

  return {
    maxLinksToCheck: row.max_links_to_check,
    requestTimeoutMs: row.request_timeout_ms,
    requireAuthConfirmation: Boolean(row.require_auth_confirmation),
  };
}

export function upsertSettingsForOwner(
  ownerKey: string,
  input: Partial<ScannerSettings>
): ScannerSettings {
  const current = getSettingsForOwner(ownerKey);
  const next: ScannerSettings = {
    maxLinksToCheck: Math.min(20, Math.max(3, Number(input.maxLinksToCheck ?? current.maxLinksToCheck))),
    requestTimeoutMs: Math.min(15000, Math.max(4000, Number(input.requestTimeoutMs ?? current.requestTimeoutMs))),
    requireAuthConfirmation:
      typeof input.requireAuthConfirmation === 'boolean'
        ? input.requireAuthConfirmation
        : current.requireAuthConfirmation,
  };

  db.prepare(
    `INSERT INTO settings (owner_key, max_links_to_check, request_timeout_ms, require_auth_confirmation, updated_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(owner_key) DO UPDATE SET
       max_links_to_check = excluded.max_links_to_check,
       request_timeout_ms = excluded.request_timeout_ms,
       require_auth_confirmation = excluded.require_auth_confirmation,
       updated_at = excluded.updated_at`
  ).run(
    ownerKey,
    next.maxLinksToCheck,
    next.requestTimeoutMs,
    next.requireAuthConfirmation ? 1 : 0,
    new Date().toISOString()
  );

  return next;
}

// In-Memory / JSON File fallback database for older Node or environments without SQLite
function createJsonFallbackDb(jsonPath: string): DbInstance {
  interface StorageData {
    users: DbUserRow[];
    sessions: Array<{ token: string; user_id: string; expires_at: string; created_at: string }>;
    scans: Array<{
      id: string;
      owner_key: string;
      user_id: string | null;
      url: string;
      final_url: string;
      overall_score: number;
      security_score: number;
      performance_score: number;
      seo_score: number;
      availability_score: number;
      passed_count: number;
      warning_count: number;
      failed_count: number;
      status_code: number;
      response_time_ms: number;
      report_json: string;
      created_at: string;
    }>;
    settings: Record<string, ScannerSettings & { updated_at: string }>;
  }

  let data: StorageData = { users: [], sessions: [], scans: [], settings: {} };
  try {
    if (fs.existsSync(jsonPath)) {
      data = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
    }
  } catch {
    // start empty
  }

  const persist = () => {
    try {
      fs.writeFileSync(jsonPath, JSON.stringify(data, null, 2));
    } catch {
      // ignore
    }
  };

  return {
    exec() {},
    prepare(sql: string) {
      const s = sql.trim().toLowerCase();
      return {
        run(...params: unknown[]) {
          if (s.startsWith('insert into users')) {
            const [id, email, name, hash, salt, created_at] = params as string[];
            data.users.push({ id, email, name, password_hash: hash, password_salt: salt, created_at });
            persist();
            return { changes: 1 };
          }
          if (s.startsWith('insert into sessions')) {
            const [token, user_id, expires_at, created_at] = params as string[];
            data.sessions.push({ token, user_id, expires_at, created_at });
            persist();
            return { changes: 1 };
          }
          if (s.startsWith('delete from sessions')) {
            const [token] = params as string[];
            data.sessions = data.sessions.filter((x) => x.token !== token);
            persist();
            return { changes: 1 };
          }
          if (s.startsWith('update scans set owner_key')) {
            const [userOwnerKey, userId, guestOwnerKey] = params as string[];
            let count = 0;
            data.scans.forEach((x) => {
              if (x.owner_key === guestOwnerKey) {
                x.owner_key = userOwnerKey;
                x.user_id = userId;
                count++;
              }
            });
            persist();
            return { changes: count };
          }
          if (s.startsWith('insert into scans')) {
            const [id, owner_key, user_id, url, final_url, overall, sec, perf, seo, avail, pCount, wCount, fCount, code, rTime, rJson, created] = params as any[];
            data.scans.push({
              id, owner_key, user_id, url, final_url,
              overall_score: overall, security_score: sec, performance_score: perf,
              seo_score: seo, availability_score: avail, passed_count: pCount,
              warning_count: wCount, failed_count: fCount, status_code: code,
              response_time_ms: rTime, report_json: rJson, created_at: created
            });
            persist();
            return { changes: 1 };
          }
          if (s.startsWith('delete from scans')) {
            const [id, ownerKey] = params as string[];
            const before = data.scans.length;
            data.scans = data.scans.filter((x) => !(x.id === id && x.owner_key === ownerKey));
            persist();
            return { changes: before - data.scans.length };
          }
          if (s.startsWith('update scans set report_json')) {
            const [rJson, id, ownerKey] = params as string[];
            const item = data.scans.find((x) => x.id === id && x.owner_key === ownerKey);
            if (item) {
              item.report_json = rJson;
              persist();
              return { changes: 1 };
            }
            return { changes: 0 };
          }
          if (s.startsWith('insert into settings')) {
            const [ownerKey, maxLinks, timeout, reqAuth, updated] = params as any[];
            data.settings[ownerKey] = {
              maxLinksToCheck: maxLinks,
              requestTimeoutMs: timeout,
              requireAuthConfirmation: Boolean(reqAuth),
              updated_at: updated
            };
            persist();
            return { changes: 1 };
          }
          return { changes: 0 };
        },
        get(...params: unknown[]) {
          if (s.includes('from users where email = ?')) {
            const [email] = params as string[];
            return data.users.find((u) => u.email === email);
          }
          if (s.includes('from users where id = ?')) {
            const [id] = params as string[];
            return data.users.find((u) => u.id === id);
          }
          if (s.includes('from sessions s') && s.includes('join users u')) {
            const [token] = params as string[];
            const sess = data.sessions.find((x) => x.token === token);
            if (!sess) return undefined;
            const u = data.users.find((x) => x.id === sess.user_id);
            if (!u) return undefined;
            return { id: u.id, email: u.email, name: u.name, created_at: u.created_at, expires_at: sess.expires_at };
          }
          if (s.includes('from scans where id = ? and owner_key = ?')) {
            const [id, ownerKey] = params as string[];
            const sc = data.scans.find((x) => x.id === id && x.owner_key === ownerKey);
            return sc ? { report_json: sc.report_json } : undefined;
          }
          if (s.includes('from settings where owner_key = ?')) {
            const [ownerKey] = params as string[];
            const st = data.settings[ownerKey];
            return st
              ? {
                  max_links_to_check: st.maxLinksToCheck,
                  request_timeout_ms: st.requestTimeoutMs,
                  require_auth_confirmation: st.requireAuthConfirmation ? 1 : 0
                }
              : undefined;
          }
          return undefined;
        },
        all(...params: unknown[]) {
          if (s.includes('from scans where owner_key = ?')) {
            const [ownerKey, limit] = params as [string, number];
            return data.scans
              .filter((x) => x.owner_key === ownerKey)
              .sort((a, b) => b.created_at.localeCompare(a.created_at))
              .slice(0, limit);
          }
          return [];
        }
      };
    }
  };
}
