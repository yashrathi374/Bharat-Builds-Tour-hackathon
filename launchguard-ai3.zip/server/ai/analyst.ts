import type { AIAnalysisResult, ScanReport } from '../../src/types/scan.ts';

const MODEL_NAME = 'gemini-2.5-flash';

const Type = {
  OBJECT: 'OBJECT',
  STRING: 'STRING',
  ARRAY: 'ARRAY',
  INTEGER: 'INTEGER',
  BOOLEAN: 'BOOLEAN',
} as const;

async function buildClient(): Promise<any | null> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  try {
    // @ts-expect-error dynamic import
    const { GoogleGenAI } = await import('@google/genai');
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'launchguard-ai',
        },
      },
    });
  } catch {
    return null;
  }
}

export async function generateAIWebsiteAnalysis(
  report: Omit<ScanReport, 'ai'>
): Promise<AIAnalysisResult> {
  const ai = await buildClient();
  if (!ai) {
    return {
      status: 'unavailable',
      errorMessage:
        'AI Website Analyst requires GEMINI_API_KEY in the server environment (configure in Settings > Secrets). Deterministic scan findings above are complete and unaffected.',
    };
  }

  // Send strictly factual, verified scan metrics to Gemini
  const factualPayload = {
    url: report.url,
    finalUrl: report.finalUrl,
    scannedAt: report.scannedAt,
    scores: report.score,
    availability: {
      statusCode: report.availability.statusCode,
      responseTimeMs: report.availability.responseTimeMs,
      isHttps: report.availability.isHttps,
      httpToHttpsRedirect: report.availability.httpToHttpsRedirect,
      redirectCount: report.availability.redirectChain.length,
    },
    security: {
      httpsEnabled: report.security.httpsEnabled,
      tls: report.security.tls,
      headers: report.security.headers,
      serverExposure: report.security.serverExposure,
    },
    performance: {
      responseTimeMs: report.performance.responseTimeMs,
      htmlSizeKb: report.performance.htmlSizeKb,
      contentEncoding: report.performance.contentEncoding,
      imageCount: report.performance.imageCount,
      imagesWithoutLazyLoading: report.performance.imagesWithoutLazyLoading,
      totalExternalResources: report.performance.totalExternalResources,
    },
    seo: {
      title: report.seo.title,
      titleLength: report.seo.titleLength,
      metaDescriptionPresent: Boolean(report.seo.metaDescription),
      metaDescriptionLength: report.seo.metaDescriptionLength,
      h1Count: report.seo.h1Count,
      viewportMeta: Boolean(report.seo.viewportMeta),
      ogConfigured: Boolean(report.seo.ogTitle && report.seo.ogDescription),
      imagesMissingAlt: report.seo.imagesMissingAlt,
    },
    links: {
      checkedCount: report.links.checkedCount,
      brokenCount: report.links.brokenCount,
      brokenUrls: report.links.links
        .filter((l) => !l.ok)
        .map((l) => ({ url: l.url, statusCode: l.statusCode, error: l.error })),
    },
    detectedIssues: report.allFindings
      .filter((f) => f.status !== 'pass')
      .map((f) => ({
        title: f.title,
        category: f.category,
        severity: f.severity,
        status: f.status,
        observedValue: f.observedValue,
        expectedValue: f.expectedValue,
      })),
    passedChecks: report.allFindings
      .filter((f) => f.status === 'pass')
      .map((f) => f.title),
  };

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Analyze this factual website scan report and produce a beginner-friendly launch readiness review:\n\n${JSON.stringify(
        factualPayload,
        null,
        2
      )}`,
      config: {
        systemInstruction:
          'You are LaunchGuard AI, a senior cybersecurity and web launch advisor writing for beginners, students, and startup founders. ' +
          'STRICT FACTUALITY RULE: Base every single statement exclusively on the provided JSON scan data. ' +
          'NEVER invent vulnerabilities, headers, broken links, or scores that are not in the JSON. ' +
          'Do not claim a penetration test was performed. ' +
          'Explain technical concepts in plain, calm, actionable English. ' +
          'Keep the executive summary concise (2-3 sentences). ' +
          'For prioritizedFixes, cover ONLY the items listed in detectedIssues (up to 6 most important issues). If detectedIssues is empty, return an empty array for prioritizedFixes.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            executiveSummary: {
              type: Type.STRING,
              description: '2-3 sentence plain-language summary grounded strictly in the scan metrics.',
            },
            launchVerdict: {
              type: Type.STRING,
              description: 'One short practical sentence on whether the site is ready to launch or what to fix first.',
            },
            topStrengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Up to 4 factual strengths from passedChecks.',
            },
            prioritizedFixes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  findingTitle: { type: Type.STRING },
                  severity: {
                    type: Type.STRING,
                    enum: ['critical', 'high', 'medium', 'low'],
                  },
                  plainEnglishExplanation: { type: Type.STRING },
                  whyItMatters: { type: Type.STRING },
                  potentialRisk: { type: Type.STRING },
                  stepByStepFix: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  howToVerify: { type: Type.STRING },
                },
                required: [
                  'findingTitle',
                  'severity',
                  'plainEnglishExplanation',
                  'whyItMatters',
                  'potentialRisk',
                  'stepByStepFix',
                  'howToVerify',
                ],
              },
            },
            glossary: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  term: { type: Type.STRING },
                  simpleExplanation: { type: Type.STRING },
                },
                required: ['term', 'simpleExplanation'],
              },
              description: '3 to 5 technical terms referenced in this scan explained in everyday language.',
            },
            launchChecklist: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  task: { type: Type.STRING },
                  category: {
                    type: Type.STRING,
                    enum: ['Security', 'Performance', 'SEO', 'Availability', 'Links'],
                  },
                  priority: {
                    type: Type.STRING,
                    enum: ['Before Launch', 'Recommended', 'Monitor'],
                  },
                  completed: { type: Type.BOOLEAN },
                },
                required: ['task', 'category', 'priority', 'completed'],
              },
              description: '6 to 8 concrete checklist items derived strictly from the scan results.',
            },
          },
          required: [
            'executiveSummary',
            'launchVerdict',
            'topStrengths',
            'prioritizedFixes',
            'glossary',
            'launchChecklist',
          ],
        },
      },
    });

    const rawText = (response.text ?? '').trim();
    if (!rawText) {
      return {
        status: 'error',
        model: MODEL_NAME,
        errorMessage: 'AI model returned an empty response.',
      };
    }

    const parsed = JSON.parse(rawText) as Omit<
      AIAnalysisResult,
      'status' | 'model' | 'generatedAt'
    >;

    return {
      status: 'completed',
      model: MODEL_NAME,
      generatedAt: new Date().toISOString(),
      ...parsed,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown AI service error';
    return {
      status: 'error',
      model: MODEL_NAME,
      errorMessage: `AI Website Analyst could not complete (${message}). Verify GEMINI_API_KEY in Settings > Secrets.`,
    };
  }
}
