import dns from 'dns/promises';
import net from 'net';
import http from 'http';
import https from 'https';
import zlib from 'zlib';
import type { RedirectHop } from '../../src/types/scan.ts';

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'ip6-localhost',
  'ip6-loopback',
  'metadata.google.internal',
  'metadata',
  '169.254.169.254',
]);

const BLOCKED_TLDS = ['.local', '.localhost', '.internal', '.lan', '.home.arpa', '.corp'];

function ipv4ToInt(ip: string): number {
  const parts = ip.split('.').map(Number);
  return (((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0);
}

function isPrivateOrReservedIPv4(ip: string): boolean {
  const n = ipv4ToInt(ip);
  const inRange = (start: string, end: string) =>
    n >= ipv4ToInt(start) && n <= ipv4ToInt(end);

  return (
    inRange('0.0.0.0', '0.255.255.255') || // Current network
    inRange('10.0.0.0', '10.255.255.255') || // Private Class A
    inRange('100.64.0.0', '100.127.255.255') || // CGNAT
    inRange('127.0.0.0', '127.255.255.255') || // Loopback
    inRange('169.254.0.0', '169.254.255.255') || // Link-local / Cloud metadata
    inRange('172.16.0.0', '172.31.255.255') || // Private Class B
    inRange('192.0.0.0', '192.0.0.255') || // IETF Protocol Assignments
    inRange('192.0.2.0', '192.0.2.255') || // TEST-NET-1
    inRange('192.168.0.0', '192.168.255.255') || // Private Class C
    inRange('198.18.0.0', '198.19.255.255') || // Benchmarking
    inRange('198.51.100.0', '198.51.100.255') || // TEST-NET-2
    inRange('203.0.113.0', '203.0.113.255') || // TEST-NET-3
    inRange('224.0.0.0', '255.255.255.255') // Multicast / Reserved / Broadcast
  );
}

function isPrivateOrReservedIPv6(ip: string): boolean {
  const normalized = ip.toLowerCase().trim();
  if (normalized === '::' || normalized === '::1') return true;
  if (normalized.startsWith('::ffff:')) {
    const mappedV4 = normalized.slice(7);
    if (net.isIPv4(mappedV4)) return isPrivateOrReservedIPv4(mappedV4);
  }
  if (normalized.startsWith('fc') || normalized.startsWith('fd')) return true; // Unique local
  if (/^fe[89ab]/.test(normalized)) return true; // Link-local fe80::/10
  if (normalized.startsWith('ff')) return true; // Multicast
  if (normalized.startsWith('2001:db8:')) return true; // Documentation
  return false;
}

export function isBlockedIp(ip: string): boolean {
  const version = net.isIP(ip);
  if (version === 4) return isPrivateOrReservedIPv4(ip);
  if (version === 6) return isPrivateOrReservedIPv6(ip);
  return true;
}

export interface ValidatedTarget {
  url: URL;
  resolvedIp: string;
  family: 4 | 6;
}

export function normalizeInputUrl(rawInput: string): URL {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    throw new Error('Enter a website URL to scan.');
  }
  if (trimmed.length > 2048) {
    throw new Error('URL exceeds maximum allowed length (2048 characters).');
  }

  let candidate = trimmed;
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = `https://${candidate}`;
  }

  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new Error('Invalid URL format. Example: https://example.com');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only HTTP and HTTPS protocols are permitted.');
  }

  if (parsed.username || parsed.password) {
    throw new Error('URLs containing embedded credentials are not allowed.');
  }

  const host = parsed.hostname.toLowerCase();
  if (!host || !host.includes('.') || BLOCKED_HOSTNAMES.has(host)) {
    throw new Error('Localhost and non-public hostnames are blocked for security.');
  }

  if (BLOCKED_TLDS.some((tld) => host.endsWith(tld))) {
    throw new Error('Private network domains (.local, .internal, .lan) are blocked.');
  }

  // Block explicit raw IP literals pointing to private ranges
  const ipVersion = net.isIP(host.replace(/^\[|\]$/g, ''));
  if (ipVersion !== 0 && isBlockedIp(host.replace(/^\[|\]$/g, ''))) {
    throw new Error('Private, loopback, and reserved IP addresses are blocked.');
  }

  // Block dangerous non-standard ports if specified
  if (parsed.port) {
    const portNum = Number(parsed.port);
    if (![80, 443, 8080, 8443].includes(portNum)) {
      throw new Error('Only standard web ports (80, 443, 8080, 8443) may be scanned.');
    }
  }

  return parsed;
}

export async function validateAndResolveUrl(rawOrUrl: string | URL): Promise<ValidatedTarget> {
  const parsed = typeof rawOrUrl === 'string' ? normalizeInputUrl(rawOrUrl) : rawOrUrl;
  const host = parsed.hostname.replace(/^\[|\]$/g, '');

  const literalIpVersion = net.isIP(host);
  if (literalIpVersion === 4 || literalIpVersion === 6) {
    if (isBlockedIp(host)) {
      throw new Error(`Target IP (${host}) is in a blocked private or reserved range.`);
    }
    return { url: parsed, resolvedIp: host, family: literalIpVersion };
  }

  let records: Array<{ address: string; family: number }>;
  try {
    records = await dns.lookup(host, { all: true });
  } catch {
    throw new Error(`DNS lookup failed for ${host}. Verify the domain exists and is publicly reachable.`);
  }

  if (!records || records.length === 0) {
    throw new Error(`No public DNS records found for ${host}.`);
  }

  for (const rec of records) {
    if (isBlockedIp(rec.address)) {
      throw new Error(
        `Security policy blocked ${host} because it resolves to a private or internal address.`
      );
    }
  }

  const preferred = records.find((r) => r.family === 4) ?? records[0];
  return {
    url: parsed,
    resolvedIp: preferred.address,
    family: preferred.family === 6 ? 6 : 4,
  };
}

export interface SafeFetchOptions {
  method?: 'GET' | 'HEAD';
  timeoutMs?: number;
  maxBytes?: number;
  maxRedirects?: number;
}

export interface SafeFetchResult {
  finalUrl: string;
  resolvedIp: string;
  statusCode: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  rawByteLength: number;
  responseTimeMs: number;
  redirectChain: RedirectHop[];
}

function singlePinnedRequest(
  target: ValidatedTarget,
  method: 'GET' | 'HEAD',
  timeoutMs: number,
  maxBytes: number
): Promise<{
  statusCode: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  rawByteLength: number;
  durationMs: number;
}> {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const isHttps = target.url.protocol === 'https:';
    const port = target.url.port ? Number(target.url.port) : isHttps ? 443 : 80;
    const lib = isHttps ? https : http;

    const req = lib.request(
      {
        host: target.resolvedIp,
        port,
        method,
        path: `${target.url.pathname}${target.url.search}`,
        servername: isHttps ? target.url.hostname : undefined,
        headers: {
          Host: target.url.host,
          'User-Agent': 'LaunchGuardAI-Scanner/1.0 (+https://launchguard.ai/safe-audit)',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Encoding': 'gzip, deflate, br',
          Connection: 'close',
        },
        timeout: timeoutMs,
        rejectUnauthorized: false, // TLS validity is explicitly checked in tlsInspector so we can report invalid certs instead of blindly crashing
      },
      (res) => {
        const headers: Record<string, string> = {};
        for (const [k, v] of Object.entries(res.headers)) {
          if (typeof v === 'string') headers[k.toLowerCase()] = v;
          else if (Array.isArray(v)) headers[k.toLowerCase()] = v.join(', ');
        }

        if (method === 'HEAD' || (res.statusCode && res.statusCode >= 300 && res.statusCode < 400)) {
          res.resume();
          resolve({
            statusCode: res.statusCode ?? 0,
            statusText: res.statusMessage ?? '',
            headers,
            body: '',
            rawByteLength: 0,
            durationMs: Date.now() - start,
          });
          return;
        }

        const chunks: Buffer[] = [];
        let received = 0;

        res.on('data', (chunk: Buffer) => {
          received += chunk.length;
          if (received <= maxBytes) {
            chunks.push(chunk);
          } else {
            res.destroy();
          }
        });

        res.on('end', () => {
          const rawBuf = Buffer.concat(chunks);
          const encoding = (headers['content-encoding'] || '').toLowerCase();

          const finish = (decoded: Buffer) => {
            resolve({
              statusCode: res.statusCode ?? 0,
              statusText: res.statusMessage ?? '',
              headers,
              body: decoded.toString('utf8'),
              rawByteLength: rawBuf.length,
              durationMs: Date.now() - start,
            });
          };

          try {
            if (encoding.includes('gzip')) {
              zlib.gunzip(rawBuf, (err, out) => finish(err ? rawBuf : out));
            } else if (encoding.includes('br')) {
              zlib.brotliDecompress(rawBuf, (err, out) => finish(err ? rawBuf : out));
            } else if (encoding.includes('deflate')) {
              zlib.inflate(rawBuf, (err, out) => finish(err ? rawBuf : out));
            } else {
              finish(rawBuf);
            }
          } catch {
            finish(rawBuf);
          }
        });

        res.on('error', (err) => {
          reject(err);
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error(`Request timed out after ${timeoutMs}ms.`));
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.end();
  });
}

export async function safeFetch(
  initialUrl: string,
  options: SafeFetchOptions = {}
): Promise<SafeFetchResult> {
  const method = options.method ?? 'GET';
  const timeoutMs = Math.min(15000, Math.max(2000, options.timeoutMs ?? 10000));
  const maxBytes = options.maxBytes ?? 2 * 1024 * 1024;
  const maxRedirects = options.maxRedirects ?? 5;

  const redirectChain: RedirectHop[] = [];
  let currentUrl = initialUrl;
  let totalTime = 0;

  for (let hop = 0; hop <= maxRedirects; hop++) {
    const validated = await validateAndResolveUrl(currentUrl);
    const res = await singlePinnedRequest(validated, method, timeoutMs, maxBytes);
    totalTime += res.durationMs;

    const isRedirect =
      res.statusCode >= 300 &&
      res.statusCode < 400 &&
      Boolean(res.headers['location']);

    if (isRedirect) {
      if (hop === maxRedirects) {
        throw new Error(`Exceeded maximum redirect limit (${maxRedirects}).`);
      }
      const nextUrl = new URL(res.headers['location'], validated.url).toString();
      redirectChain.push({
        from: validated.url.toString(),
        to: nextUrl,
        statusCode: res.statusCode,
        durationMs: res.durationMs,
      });
      currentUrl = nextUrl;
      continue;
    }

    return {
      finalUrl: validated.url.toString(),
      resolvedIp: validated.resolvedIp,
      statusCode: res.statusCode,
      statusText: res.statusText,
      headers: res.headers,
      body: res.body,
      rawByteLength: res.rawByteLength,
      responseTimeMs: totalTime,
      redirectChain,
    };
  }

  throw new Error('Redirect resolution failed unexpectedly.');
}

// Sliding-window rate limiter to protect against abusive scanning
const scanTimestamps = new Map<string, number[]>();

export function checkScanRateLimit(
  key: string,
  maxRequests = 12,
  windowMs = 60_000
): { allowed: boolean; retryAfterSec?: number } {
  const now = Date.now();
  const prev = (scanTimestamps.get(key) ?? []).filter((t) => now - t < windowMs);
  if (prev.length >= maxRequests) {
    const oldest = prev[0];
    return {
      allowed: false,
      retryAfterSec: Math.ceil((windowMs - (now - oldest)) / 1000),
    };
  }
  prev.push(now);
  scanTimestamps.set(key, prev);
  return { allowed: true };
}
