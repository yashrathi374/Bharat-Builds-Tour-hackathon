import * as cheerio from 'cheerio';
import type {
  AuditFinding,
  AvailabilityResult,
  CheckedLink,
  LinkCheckSummary,
  PerformanceResult,
  ReadinessScore,
  ScoreDeduction,
  SecurityResult,
  SeoResult,
  TlsCertificateInfo,
} from '../../src/types/scan.ts';
import {
  safeFetch,
  validateAndResolveUrl,
  type SafeFetchResult,
} from '../security/ssrf.ts';
import { inspectTlsCertificate } from './tlsInspector.ts';

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function runAvailabilityCheck(
  rawUrl: string,
  timeoutMs: number
): Promise<{ availability: AvailabilityResult; fetchResult: SafeFetchResult }> {
  const fetchResult = await safeFetch(rawUrl, {
    method: 'GET',
    timeoutMs,
    maxBytes: 2 * 1024 * 1024,
    maxRedirects: 5,
  });

  const finalParsed = new URL(fetchResult.finalUrl);
  const isHttps = finalParsed.protocol === 'https:';

  // If final site is HTTPS, check whether plain HTTP redirects to HTTPS
  let httpToHttpsRedirect: boolean | null = null;
  if (isHttps) {
    try {
      const httpUrl = `http://${finalParsed.host}${finalParsed.pathname}`;
      const httpProbe = await safeFetch(httpUrl, {
        method: 'HEAD',
        timeoutMs: Math.min(4500, timeoutMs),
        maxRedirects: 3,
      });
      httpToHttpsRedirect = new URL(httpProbe.finalUrl).protocol === 'https:';
    } catch {
      httpToHttpsRedirect = null;
    }
  } else {
    httpToHttpsRedirect = false;
  }

  const availability: AvailabilityResult = {
    requestedUrl: rawUrl,
    finalUrl: fetchResult.finalUrl,
    reachable: fetchResult.statusCode > 0 && fetchResult.statusCode < 500,
    statusCode: fetchResult.statusCode,
    statusText: fetchResult.statusText || (fetchResult.statusCode < 400 ? 'OK' : 'Error'),
    responseTimeMs: fetchResult.responseTimeMs,
    isHttps,
    httpToHttpsRedirect,
    redirectChain: fetchResult.redirectChain,
    resolvedIp: fetchResult.resolvedIp,
    contentType: fetchResult.headers['content-type'] ?? 'unknown',
  };

  return { availability, fetchResult };
}

export async function runSecurityAnalysis(
  availability: AvailabilityResult,
  headers: Record<string, string>,
  timeoutMs: number
): Promise<SecurityResult> {
  const finalTarget = await validateAndResolveUrl(availability.finalUrl);
  const tls: TlsCertificateInfo = await inspectTlsCertificate(
    finalTarget,
    Math.min(7000, timeoutMs)
  );

  const trackedHeaderNames = [
    'content-security-policy',
    'x-frame-options',
    'x-content-type-options',
    'strict-transport-security',
    'referrer-policy',
    'permissions-policy',
  ];

  const trackedHeaders: Record<string, string | null> = {};
  for (const h of trackedHeaderNames) {
    trackedHeaders[h] = headers[h] ?? null;
  }

  const serverHeader = headers['server'] ?? null;
  const poweredByHeader = headers['x-powered-by'] ?? null;
  const serverVersionPattern = /[\d]+\.[\d]+|express|php|apache|nginx\/|iis\/|next\.js/i;
  const serverExposed = Boolean(
    poweredByHeader || (serverHeader && serverVersionPattern.test(serverHeader))
  );

  const findings: AuditFinding[] = [];

  // 1. HTTPS availability
  if (availability.isHttps) {
    findings.push({
      id: 'sec-https',
      category: 'security',
      title: 'HTTPS Encryption Active',
      severity: 'pass',
      status: 'pass',
      observedValue: 'HTTPS (TLS)',
      expectedValue: 'HTTPS',
      explanation: 'Your website serves traffic over encrypted HTTPS.',
      recommendation: 'Keep HTTPS enforced across all pages and API endpoints.',
    });
  } else {
    findings.push({
      id: 'sec-https',
      category: 'security',
      title: 'HTTPS Not Enabled',
      severity: 'critical',
      status: 'fail',
      observedValue: 'Plain HTTP',
      expectedValue: 'HTTPS',
      explanation:
        'Traffic between visitors and your website is unencrypted and browsers mark the site as Not Secure.',
      recommendation: 'Provision an SSL/TLS certificate and redirect all HTTP traffic to HTTPS.',
      fixGuide: {
        whatIsTheProblem: 'The website responded over unencrypted HTTP instead of HTTPS.',
        whyItMatters:
          'Modern browsers warn visitors away from HTTP sites, and login forms or cookies can be intercepted on public Wi-Fi.',
        potentialRisk:
          'Attackers on the same network can read or modify page data, steal credentials, or inject malicious scripts.',
        howToFix:
          'Enable automatic TLS certificates on your hosting provider (Vercel, Netlify, Cloudflare, or Let’s Encrypt via Certbot) and turn on Force HTTPS.',
        stepByStep: [
          'Open your hosting provider dashboard (e.g., Cloudflare, Vercel, Netlify, or Render).',
          'Navigate to Domains or SSL/TLS settings and enable an automated TLS certificate.',
          'Enable "Always Use HTTPS" or configure a 301 redirect from http:// to https://.',
          'Update any hard-coded http:// links inside your templates to https://.',
        ],
        howToVerify:
          'Visit http://yourdomain.com in a private browser window and confirm it automatically redirects to https:// with a valid padlock.',
      },
    });
  }

  // 2. TLS certificate validity & expiry
  if (availability.isHttps) {
    if (tls.valid && typeof tls.daysRemaining === 'number' && tls.daysRemaining > 14) {
      findings.push({
        id: 'sec-tls-cert',
        category: 'security',
        title: 'SSL/TLS Certificate Valid',
        severity: 'pass',
        status: 'pass',
        observedValue: `Valid (${tls.daysRemaining} days remaining, ${tls.protocol ?? 'TLS'})`,
        expectedValue: 'Trusted, unexpired certificate (>14 days)',
        explanation: `Certificate issued by ${tls.issuer ?? 'trusted CA'} is valid until ${tls.validTo ? new Date(tls.validTo).toLocaleDateString() : 'N/A'}.`,
        recommendation: 'Ensure automated certificate renewal stays active.',
      });
    } else if (tls.valid && typeof tls.daysRemaining === 'number' && tls.daysRemaining <= 14) {
      findings.push({
        id: 'sec-tls-cert',
        category: 'security',
        title: 'SSL/TLS Certificate Expiring Soon',
        severity: 'high',
        status: 'warning',
        observedValue: `${tls.daysRemaining} days remaining`,
        expectedValue: '> 14 days remaining',
        explanation: 'Your SSL certificate is close to expiration.',
        recommendation: 'Renew your certificate or verify auto-renewal before it expires.',
        fixGuide: {
          whatIsTheProblem: `Your TLS certificate expires in ${tls.daysRemaining} days.`,
          whyItMatters:
            'Once a certificate expires, browsers block visitors with a full-screen security warning.',
          potentialRisk: 'Complete site outage for normal users and loss of visitor trust.',
          howToFix: 'Renew the certificate now and confirm automated renewal (ACME / Let’s Encrypt).',
          stepByStep: [
            'Log in to your DNS/hosting provider or run `sudo certbot renew` on your server.',
            'Check your renewal cron job or managed SSL status.',
            'Reload your web server (Nginx/Caddy/Apache) if self-hosted.',
          ],
          howToVerify:
            'Re-run a LaunchGuard AI scan and confirm the certificate expiry date is extended.',
        },
      });
    } else {
      findings.push({
        id: 'sec-tls-cert',
        category: 'security',
        title: 'SSL/TLS Certificate Issue Detected',
        severity: 'critical',
        status: 'fail',
        observedValue: tls.authorizationError || tls.error || 'Invalid or untrusted certificate',
        expectedValue: 'Valid CA-signed certificate matching hostname',
        explanation:
          'The server certificate failed trust or expiration verification during the TLS handshake.',
        recommendation: 'Install a valid CA-signed certificate matching your exact domain.',
        fixGuide: {
          whatIsTheProblem:
            tls.authorizationError || tls.error || 'The TLS certificate is expired, self-signed, or mismatched.',
          whyItMatters:
            'Browsers refuse to load sites with untrusted certificates unless users bypass intimidating warnings.',
          potentialRisk:
            'Visitors cannot distinguish your genuine server from an impersonator (man-in-the-middle attack).',
          howToFix: 'Issue a fresh certificate covering both the apex domain and www subdomain.',
          stepByStep: [
            'Verify the domain DNS A/CNAME records point to the correct host.',
            'Re-issue the certificate through your hosting provider or Let’s Encrypt.',
            'Ensure the full intermediate certificate chain is served by your server.',
          ],
          howToVerify:
            'Open your site in an incognito browser and verify no certificate warning appears, then re-scan.',
        },
      });
    }
  }

  // 3. Content-Security-Policy
  if (trackedHeaders['content-security-policy']) {
    findings.push({
      id: 'sec-csp',
      category: 'security',
      title: 'Content-Security-Policy Configured',
      severity: 'pass',
      status: 'pass',
      observedValue: trackedHeaders['content-security-policy'].slice(0, 120),
      expectedValue: 'Present',
      explanation: 'A Content-Security-Policy (CSP) header restricts where scripts and assets can load from.',
      recommendation: 'Periodically audit CSP directives to minimize unsafe-inline or wildcard sources.',
    });
  } else {
    findings.push({
      id: 'sec-csp',
      category: 'security',
      title: 'Missing Content-Security-Policy (CSP) Header',
      severity: 'high',
      status: 'fail',
      observedValue: 'Not set',
      expectedValue: "default-src 'self'; ...",
      explanation:
        'Without a Content-Security-Policy header, browsers allow scripts from any injected source to run inside your page.',
      recommendation: 'Add a baseline Content-Security-Policy header tailored to your asset origins.',
      fixGuide: {
        whatIsTheProblem: 'The HTTP response does not include a Content-Security-Policy header.',
        whyItMatters:
          'CSP acts as an allowlist telling the browser which domains are permitted to execute JavaScript, load styles, or embed frames.',
        potentialRisk:
          'If your app ever has a Cross-Site Scripting (XSS) bug or a compromised third-party dependency, attackers can run arbitrary scripts and exfiltrate user sessions.',
        howToFix:
          'Start with a Content-Security-Policy-Report-Only header to test, then enforce a strict Content-Security-Policy header via your web server or hosting config.',
        stepByStep: [
          'List every external domain your app genuinely needs (fonts, analytics, APIs).',
          'Add the header in your hosting config (e.g., vercel.json, netlify.toml, Nginx, or Express Helmet).',
          'Test every page while watching the browser Developer Tools Console for any blocked resource warnings.',
          'Tighten directives once all legitimate assets load cleanly.',
        ],
        howToVerify:
          'Open DevTools -> Network -> click the main document -> check Response Headers for Content-Security-Policy, or re-scan here.',
        codeSnippet: `Content-Security-Policy: default-src 'self'; img-src 'self' https: data:; script-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none';`,
      },
    });
  }

  // 4. X-Frame-Options (or frame-ancestors in CSP)
  const cspHasFrameAncestors = Boolean(
    trackedHeaders['content-security-policy'] &&
      /frame-ancestors/i.test(trackedHeaders['content-security-policy'])
  );
  if (trackedHeaders['x-frame-options'] || cspHasFrameAncestors) {
    findings.push({
      id: 'sec-xfo',
      category: 'security',
      title: 'Clickjacking Protection Active',
      severity: 'pass',
      status: 'pass',
      observedValue:
        trackedHeaders['x-frame-options'] || 'Protected via CSP frame-ancestors',
      expectedValue: 'DENY or SAMEORIGIN',
      explanation: 'The site prevents unauthorized third-party pages from embedding it in hidden iframes.',
      recommendation: 'Keep X-Frame-Options or CSP frame-ancestors enabled.',
    });
  } else {
    findings.push({
      id: 'sec-xfo',
      category: 'security',
      title: 'Missing X-Frame-Options Header',
      severity: 'medium',
      status: 'warning',
      observedValue: 'Not set',
      expectedValue: 'DENY or SAMEORIGIN',
      explanation: 'Your site can currently be embedded inside an iframe on any external domain.',
      recommendation: 'Set X-Frame-Options: DENY (or SAMEORIGIN) and CSP frame-ancestors.',
      fixGuide: {
        whatIsTheProblem:
          'Neither X-Frame-Options nor CSP frame-ancestors was found in the response headers.',
        whyItMatters:
          'Without framing protection, another website can overlay invisible buttons over your page.',
        potentialRisk:
          'Clickjacking attacks could trick signed-in users into clicking buttons (like deleting data or changing settings) without realizing it.',
        howToFix: 'Send X-Frame-Options: SAMEORIGIN (or DENY if you never iframe your own pages).',
        stepByStep: [
          'Open your server middleware or hosting headers configuration file.',
          'Add `X-Frame-Options: DENY` (or `SAMEORIGIN` if you embed your own pages).',
          'Deploy the updated configuration.',
        ],
        howToVerify:
          'Run `curl -I https://yourdomain.com` or re-scan with LaunchGuard AI and verify X-Frame-Options is listed.',
        codeSnippet: `X-Frame-Options: DENY`,
      },
    });
  }

  // 5. X-Content-Type-Options
  if (
    trackedHeaders['x-content-type-options'] &&
    trackedHeaders['x-content-type-options'].toLowerCase().includes('nosniff')
  ) {
    findings.push({
      id: 'sec-xcto',
      category: 'security',
      title: 'MIME-Sniffing Protection Enabled',
      severity: 'pass',
      status: 'pass',
      observedValue: trackedHeaders['x-content-type-options'],
      expectedValue: 'nosniff',
      explanation: 'Browsers are instructed to strictly follow declared Content-Type headers.',
      recommendation: 'No change needed.',
    });
  } else {
    findings.push({
      id: 'sec-xcto',
      category: 'security',
      title: 'Missing X-Content-Type-Options: nosniff',
      severity: 'medium',
      status: 'warning',
      observedValue: trackedHeaders['x-content-type-options'] ?? 'Not set',
      expectedValue: 'nosniff',
      explanation:
        'Browsers may try to guess ("sniff") file types instead of trusting the declared Content-Type.',
      recommendation: 'Add the header X-Content-Type-Options: nosniff to all responses.',
      fixGuide: {
        whatIsTheProblem: 'The X-Content-Type-Options header is missing or not set to nosniff.',
        whyItMatters:
          'If users upload files or images, older/lenient browser behavior can interpret an innocent-looking text or image file as executable JavaScript.',
        potentialRisk: 'MIME-confusion XSS attacks against users viewing uploaded or dynamic files.',
        howToFix: 'Set `X-Content-Type-Options: nosniff` globally on your server or CDN.',
        stepByStep: [
          'In Express, add `res.setHeader("X-Content-Type-Options", "nosniff")` or install `helmet`.',
          'On Vercel/Netlify/Cloudflare, add the header rule for `/*`.',
          'Redeploy and verify the response headers.',
        ],
        howToVerify: 'Inspect response headers in DevTools Network tab or re-run this scan.',
        codeSnippet: `X-Content-Type-Options: nosniff`,
      },
    });
  }

  // 6. Strict-Transport-Security (HSTS)
  if (trackedHeaders['strict-transport-security']) {
    findings.push({
      id: 'sec-hsts',
      category: 'security',
      title: 'Strict-Transport-Security (HSTS) Enabled',
      severity: 'pass',
      status: 'pass',
      observedValue: trackedHeaders['strict-transport-security'],
      expectedValue: 'max-age>=31536000',
      explanation: 'Browsers remember to connect to this domain exclusively over HTTPS.',
      recommendation: 'Ensure max-age is at least 31536000 (1 year) once HTTPS is stable.',
    });
  } else {
    findings.push({
      id: 'sec-hsts',
      category: 'security',
      title: 'Missing Strict-Transport-Security (HSTS) Header',
      severity: availability.isHttps ? 'medium' : 'high',
      status: availability.isHttps ? 'warning' : 'fail',
      observedValue: 'Not set',
      expectedValue: 'max-age=31536000; includeSubDomains',
      explanation:
        'Without HSTS, visitors typing your domain without https:// make an initial unencrypted request that could be intercepted.',
      recommendation: 'Enable Strict-Transport-Security after confirming full HTTPS support.',
      fixGuide: {
        whatIsTheProblem: 'The Strict-Transport-Security (HSTS) response header is missing.',
        whyItMatters:
          'HSTS tells browsers to automatically upgrade all future requests to HTTPS before even contacting your server.',
        potentialRisk:
          'SSL stripping attacks on untrusted Wi-Fi networks can downgrade a user’s first visit to HTTP.',
        howToFix:
          'Add Strict-Transport-Security with a short max-age first (e.g., 3600), then increase to 31536000 (1 year).',
        stepByStep: [
          'Confirm every page and subdomain works reliably over HTTPS.',
          'Add `Strict-Transport-Security: max-age=31536000; includeSubDomains` to your HTTPS response headers.',
          'Deploy and verify via a fresh scan.',
        ],
        howToVerify:
          'Check for the Strict-Transport-Security header on the HTTPS response in LaunchGuard AI.',
        codeSnippet: `Strict-Transport-Security: max-age=31536000; includeSubDomains`,
      },
    });
  }

  // 7. Server Information Exposure
  if (serverExposed) {
    const exposedDetail = [
      serverHeader ? `Server: ${serverHeader}` : null,
      poweredByHeader ? `X-Powered-By: ${poweredByHeader}` : null,
    ]
      .filter(Boolean)
      .join(' | ');

    findings.push({
      id: 'sec-server-exposure',
      category: 'security',
      title: 'Server Software Information Exposed',
      severity: 'low',
      status: 'warning',
      observedValue: exposedDetail,
      expectedValue: 'Minimal or omitted server banners',
      explanation:
        'Response headers reveal backend software or version details (Server / X-Powered-By).',
      recommendation: 'Disable X-Powered-By and minimize Server version banners.',
      fixGuide: {
        whatIsTheProblem: `Your response includes identifying software headers (${exposedDetail}).`,
        whyItMatters:
          'Automated scanners look for exact framework and server version numbers to match known vulnerabilities.',
        potentialRisk:
          'Makes reconnaissance faster for automated bots targeting specific versions of Express, PHP, Nginx, or Apache.',
        howToFix:
          'Disable the X-Powered-By header in your framework and turn off server tokens in your web server.',
        stepByStep: [
          'In Express.js, call `app.disable("x-powered-by")` or use Helmet.',
          'In Nginx, add `server_tokens off;` inside the `http` block.',
          'In Next.js, set `poweredByHeader: false` in next.config.js.',
        ],
        howToVerify:
          'Re-scan your URL and verify X-Powered-By is gone and Server does not include version numbers.',
        codeSnippet: `// Express.js\napp.disable('x-powered-by');`,
      },
    });
  } else {
    findings.push({
      id: 'sec-server-exposure',
      category: 'security',
      title: 'Minimal Server Fingerprinting',
      severity: 'pass',
      status: 'pass',
      observedValue: serverHeader ? `Server: ${serverHeader} (no version leak)` : 'Headers hidden',
      expectedValue: 'No detailed version banners',
      explanation: 'Response headers do not expose detailed backend framework or version numbers.',
      recommendation: 'Keep X-Powered-By disabled in production.',
    });
  }

  return {
    httpsEnabled: availability.isHttps,
    tls,
    headers: trackedHeaders,
    serverExposure: {
      serverHeader,
      poweredByHeader,
      exposed: serverExposed,
    },
    findings,
    scopeDisclaimer:
      'Automated passive surface & HTTP/TLS configuration audit. This check does not execute scripts, brute-force endpoints, or replace a full manual penetration test.',
  };
}

export function runPerformanceAnalysis(
  fetchResult: SafeFetchResult,
  $: cheerio.CheerioAPI
): PerformanceResult {
  const htmlSizeBytes = Buffer.byteLength(fetchResult.body, 'utf8');
  const htmlSizeKb = Number((htmlSizeBytes / 1024).toFixed(1));
  const contentEncoding = fetchResult.headers['content-encoding'] ?? null;
  const cacheControl = fetchResult.headers['cache-control'] ?? null;
  const baseOrigin = new URL(fetchResult.finalUrl).origin;

  const images = $('img');
  const imageCount = images.length;
  let imagesWithoutLazyLoading = 0;
  let imagesWithoutDimensions = 0;

  images.each((idx, el) => {
    const loading = ($(el).attr('loading') || '').toLowerCase();
    // Skip first 2 hero images when checking lazy loading
    if (idx >= 2 && loading !== 'lazy') {
      imagesWithoutLazyLoading++;
    }
    const hasW = Boolean($(el).attr('width'));
    const hasH = Boolean($(el).attr('height'));
    if (!hasW || !hasH) {
      imagesWithoutDimensions++;
    }
  });

  const externalDomainsSet = new Set<string>();
  let externalScriptCount = 0;
  let inlineScriptCount = 0;

  $('script').each((_, el) => {
    const src = $(el).attr('src');
    if (src) {
      externalScriptCount++;
      try {
        const resolved = new URL(src, fetchResult.finalUrl);
        if (resolved.origin !== baseOrigin) {
          externalDomainsSet.add(resolved.hostname);
        }
      } catch {
        // ignore malformed src
      }
    } else {
      inlineScriptCount++;
    }
  });

  let externalStylesheetCount = 0;
  $('link[rel="stylesheet"]').each((_, el) => {
    const href = $(el).attr('href');
    if (href) {
      externalStylesheetCount++;
      try {
        const resolved = new URL(href, fetchResult.finalUrl);
        if (resolved.origin !== baseOrigin) {
          externalDomainsSet.add(resolved.hostname);
        }
      } catch {
        // ignore malformed href
      }
    }
  });

  const totalExternalResources = externalScriptCount + externalStylesheetCount;
  const externalDomains = Array.from(externalDomainsSet).slice(0, 20);
  const findings: AuditFinding[] = [];

  // Response time check
  if (fetchResult.responseTimeMs <= 600) {
    findings.push({
      id: 'perf-ttfb',
      category: 'performance',
      title: 'Fast Server Response Time',
      severity: 'pass',
      status: 'pass',
      observedValue: `${fetchResult.responseTimeMs} ms`,
      expectedValue: '<= 600 ms',
      explanation: 'Your server delivered the HTML document quickly.',
      recommendation: 'Monitor response time as user traffic grows.',
    });
  } else if (fetchResult.responseTimeMs <= 1500) {
    findings.push({
      id: 'perf-ttfb',
      category: 'performance',
      title: 'Moderate Server Response Time',
      severity: 'medium',
      status: 'warning',
      observedValue: `${fetchResult.responseTimeMs} ms`,
      expectedValue: '<= 600 ms',
      explanation: 'Initial HTML response took longer than the ideal 600ms target.',
      recommendation: 'Enable edge caching / CDN and optimize slow database queries on landing pages.',
      fixGuide: {
        whatIsTheProblem: `The initial page response took ${fetchResult.responseTimeMs}ms.`,
        whyItMatters:
          'Users wait for the HTML document before the browser can even begin downloading CSS, fonts, and images.',
        potentialRisk: 'Higher bounce rates on mobile networks and lower Core Web Vitals scores.',
        howToFix:
          'Put a CDN in front of your site, cache public HTML pages, and avoid cold starts on serverless functions.',
        stepByStep: [
          'Check if your hosting region is close to your users.',
          'Add Cache-Control headers for static/public pages.',
          'Profile any server-side API calls made before rendering the first page.',
        ],
        howToVerify: 'Re-run LaunchGuard AI and verify response time drops below 600ms.',
      },
    });
  } else {
    findings.push({
      id: 'perf-ttfb',
      category: 'performance',
      title: 'Slow Server Response Time',
      severity: 'high',
      status: 'fail',
      observedValue: `${fetchResult.responseTimeMs} ms`,
      expectedValue: '<= 600 ms',
      explanation: 'Server response exceeded 1.5 seconds, creating a noticeable blank screen delay.',
      recommendation: 'Investigate backend bottlenecks, enable caching, or use static pre-rendering.',
      fixGuide: {
        whatIsTheProblem: `The server took ${fetchResult.responseTimeMs}ms to respond.`,
        whyItMatters: 'Slow Time to First Byte delays everything else on the page.',
        potentialRisk: 'Visitors may assume the site is broken and leave before it finishes loading.',
        howToFix: 'Cache rendered pages at the CDN edge and eliminate blocking server-side work.',
        stepByStep: [
          'Enable CDN caching (Cloudflare, Vercel Edge, or Fastly).',
          'Check server logs for slow database queries or external API calls on page load.',
          'Pre-render marketing/landing pages as static HTML instead of computing on every request.',
        ],
        howToVerify: 'Re-scan after deploying caching changes and confirm latency improves.',
      },
    });
  }

  // HTML payload size check
  if (htmlSizeKb <= 150) {
    findings.push({
      id: 'perf-html-size',
      category: 'performance',
      title: 'Lean HTML Document Size',
      severity: 'pass',
      status: 'pass',
      observedValue: `${htmlSizeKb} KB`,
      expectedValue: '<= 150 KB',
      explanation: 'The HTML document size is compact and quick to parse.',
      recommendation: 'Keep initial HTML free of large embedded base64 assets or unused JSON.',
    });
  } else {
    findings.push({
      id: 'perf-html-size',
      category: 'performance',
      title: 'Large HTML Payload',
      severity: htmlSizeKb > 400 ? 'high' : 'medium',
      status: htmlSizeKb > 400 ? 'fail' : 'warning',
      observedValue: `${htmlSizeKb} KB`,
      expectedValue: '<= 150 KB',
      explanation: 'The downloaded HTML document is large, increasing parse and transfer time.',
      recommendation: 'Trim serialized state in HTML, remove inline SVGs/base64 blobs, and enable Brotli/Gzip.',
      fixGuide: {
        whatIsTheProblem: `The uncompressed HTML document is ${htmlSizeKb} KB.`,
        whyItMatters: 'Large HTML files slow down mobile browsers and delay First Contentful Paint.',
        potentialRisk: 'Sluggish initial page loads for users on cellular connections.',
        howToFix: 'Move large inline data/images to external cached files and enable HTTP compression.',
        stepByStep: [
          'Inspect page source for huge inline JSON payloads or base64 data URIs.',
          'Ensure Gzip or Brotli compression is enabled on your web server.',
          'Paginate or lazy-load long lists instead of embedding all items in initial HTML.',
        ],
        howToVerify: 'Re-scan and check that HTML Size drops under 150 KB.',
      },
    });
  }

  // Compression check
  if (contentEncoding && /br|gzip|deflate/i.test(contentEncoding)) {
    findings.push({
      id: 'perf-compression',
      category: 'performance',
      title: 'HTTP Compression Enabled',
      severity: 'pass',
      status: 'pass',
      observedValue: contentEncoding,
      expectedValue: 'br or gzip',
      explanation: 'Text responses are compressed in transit to reduce bandwidth usage.',
      recommendation: 'No action required.',
    });
  } else if (htmlSizeKb > 5) {
    findings.push({
      id: 'perf-compression',
      category: 'performance',
      title: 'HTTP Text Compression Not Detected',
      severity: 'medium',
      status: 'warning',
      observedValue: 'None',
      expectedValue: 'br or gzip',
      explanation: 'The HTML response did not include a gzip or Brotli Content-Encoding header.',
      recommendation: 'Enable Brotli or Gzip compression on your server or CDN.',
      fixGuide: {
        whatIsTheProblem: 'Your server sent uncompressed HTML text over the network.',
        whyItMatters: 'Brotli/Gzip typically shrinks HTML, CSS, and JS transfers by 60–80%.',
        potentialRisk: 'Slower page loads and unnecessary bandwidth costs.',
        howToFix: 'Enable compression middleware or turn on automatic compression in your CDN.',
        stepByStep: [
          'In Express, add the `compression` middleware package.',
          'In Nginx, enable `gzip on;` and `gzip_types text/html text/css application/javascript;`.',
          'On Cloudflare/Vercel/Netlify, compression is built-in when routing through their edge.',
        ],
        howToVerify: 'Check for `Content-Encoding: br` or `gzip` in the scan performance metrics.',
      },
    });
  }

  // External resources check
  if (totalExternalResources > 15) {
    findings.push({
      id: 'perf-external-resources',
      category: 'performance',
      title: 'High Number of External Scripts & Stylesheets',
      severity: 'medium',
      status: 'warning',
      observedValue: `${totalExternalResources} files (${externalScriptCount} scripts, ${externalStylesheetCount} stylesheets)`,
      expectedValue: '<= 15 resources',
      explanation: 'Loading many separate scripts and stylesheets increases network overhead and render blocking.',
      recommendation: 'Bundle assets with Vite/Webpack and defer non-critical third-party scripts.',
      fixGuide: {
        whatIsTheProblem: `The page references ${totalExternalResources} external script/stylesheet files.`,
        whyItMatters: 'Every blocking script or stylesheet delays when visitors see usable content.',
        potentialRisk: 'Slow interactivity and increased exposure if third-party scripts stall.',
        howToFix: 'Remove unused libraries, bundle assets, and add `defer` or `async` to non-critical scripts.',
        stepByStep: [
          'Audit `<script>` and `<link rel="stylesheet">` tags and remove unused widgets.',
          'Add the `defer` attribute to non-essential script tags.',
          'Use a build bundler to combine local modules.',
        ],
        howToVerify: 'Re-run LaunchGuard AI and confirm external resource counts decrease.',
      },
    });
  }

  // Image lazy loading optimization
  if (imagesWithoutLazyLoading > 3) {
    findings.push({
      id: 'perf-image-lazy',
      category: 'performance',
      title: 'Below-the-Fold Images Missing Lazy Loading',
      severity: 'low',
      status: 'warning',
      observedValue: `${imagesWithoutLazyLoading} of ${imageCount} images`,
      expectedValue: 'loading="lazy" on off-screen images',
      explanation: 'Several images load immediately even before the visitor scrolls to them.',
      recommendation: 'Add loading="lazy" to images below the fold (keep the main hero image eager).',
      fixGuide: {
        whatIsTheProblem: `${imagesWithoutLazyLoading} images below the top of the page do not specify loading="lazy".`,
        whyItMatters: 'Downloading off-screen images immediately competes for bandwidth with visible content.',
        potentialRisk: 'Slower perceived load speed on mobile devices.',
        howToFix: 'Add `loading="lazy"` and explicit `width`/`height` attributes to non-hero `<img>` tags.',
        stepByStep: [
          'Leave your first above-the-fold hero image without lazy loading.',
          'Add `loading="lazy"` to all gallery, card, and footer `<img>` elements.',
          'Include `width` and `height` attributes so the layout does not jump while images load.',
        ],
        howToVerify: 'Re-scan and check the Images Without Lazy Loading counter.',
      },
    });
  }

  return {
    responseTimeMs: fetchResult.responseTimeMs,
    htmlSizeBytes,
    htmlSizeKb,
    contentEncoding,
    cacheControl,
    imageCount,
    imagesWithoutLazyLoading,
    imagesWithoutDimensions,
    externalScriptCount,
    externalStylesheetCount,
    totalExternalResources,
    externalDomains,
    inlineScriptCount,
    findings,
  };
}

export function runSeoAnalysis($: cheerio.CheerioAPI): SeoResult {
  const title = $('title').first().text().trim() || null;
  const titleLength = title ? title.length : 0;
  const metaDescription =
    $('meta[name="description"]').attr('content')?.trim() || null;
  const metaDescriptionLength = metaDescription ? metaDescription.length : 0;
  const canonicalUrl = $('link[rel="canonical"]').attr('href')?.trim() || null;

  const h1Texts: string[] = [];
  $('h1').each((_, el) => {
    const txt = $(el).text().replace(/\s+/g, ' ').trim();
    if (txt) h1Texts.push(txt.slice(0, 120));
  });
  const h1Count = $('h1').length;

  const htmlLang = $('html').attr('lang')?.trim() || null;
  const viewportMeta = $('meta[name="viewport"]').attr('content')?.trim() || null;
  const ogTitle = $('meta[property="og:title"]').attr('content')?.trim() || null;
  const ogDescription =
    $('meta[property="og:description"]').attr('content')?.trim() || null;
  const ogImage = $('meta[property="og:image"]').attr('content')?.trim() || null;
  const robotsMeta = $('meta[name="robots"]').attr('content')?.trim() || null;

  const totalImages = $('img').length;
  let imagesMissingAlt = 0;
  $('img').each((_, el) => {
    const alt = $(el).attr('alt');
    if (alt === undefined) {
      imagesMissingAlt++;
    }
  });

  const findings: AuditFinding[] = [];

  // Title check
  if (!title) {
    findings.push({
      id: 'seo-title',
      category: 'seo',
      title: 'Missing Page Title (<title>)',
      severity: 'high',
      status: 'fail',
      observedValue: 'Missing',
      expectedValue: '30–60 characters',
      explanation: 'No <title> tag was found in the HTML head.',
      recommendation: 'Add a descriptive, unique <title> tag (30–60 characters).',
      fixGuide: {
        whatIsTheProblem: 'The page lacks a `<title>` element inside `<head>`.',
        whyItMatters: 'The title appears in browser tabs, bookmarks, and as the main clickable link in Google search results.',
        potentialRisk: 'Poor search visibility and confusing browser tabs for visitors.',
        howToFix: 'Insert `<title>Your Brand — Clear Page Purpose</title>` inside `<head>`.',
        stepByStep: [
          'Open your root HTML file (`index.html` or layout template).',
          'Add a clear `<title>` tag between 30 and 60 characters.',
          'Deploy and verify the browser tab updates.',
        ],
        howToVerify: 'Check the browser tab title and re-run LaunchGuard AI.',
        codeSnippet: `<title>Your Product — Clear Value Proposition</title>`,
      },
    });
  } else if (titleLength < 15 || titleLength > 70) {
    findings.push({
      id: 'seo-title',
      category: 'seo',
      title: 'Page Title Length Outside Recommended Range',
      severity: 'low',
      status: 'warning',
      observedValue: `${titleLength} chars ("${title.slice(0, 60)}")`,
      expectedValue: '15–70 characters',
      explanation:
        titleLength < 15
          ? 'The page title is very short and may not describe the page clearly.'
          : 'The page title is long and may be truncated in search results.',
      recommendation: 'Aim for a clear title between 30 and 60 characters.',
    });
  } else {
    findings.push({
      id: 'seo-title',
      category: 'seo',
      title: 'Page Title Well-Formatted',
      severity: 'pass',
      status: 'pass',
      observedValue: `${titleLength} chars ("${title}")`,
      expectedValue: '15–70 characters',
      explanation: 'The HTML <title> tag is present and within ideal length limits.',
      recommendation: 'Keep titles unique on every page.',
    });
  }

  // Meta description check
  if (!metaDescription) {
    findings.push({
      id: 'seo-meta-desc',
      category: 'seo',
      title: 'Missing Meta Description',
      severity: 'medium',
      status: 'fail',
      observedValue: 'Missing',
      expectedValue: '70–160 characters',
      explanation: 'No <meta name="description"> tag was detected.',
      recommendation: 'Add a concise 1–2 sentence meta description summarizing what your site offers.',
      fixGuide: {
        whatIsTheProblem: 'The page does not have a `<meta name="description">` tag.',
        whyItMatters: 'Search engines display this text beneath your page title to help people decide whether to click.',
        potentialRisk: 'Search engines may pull random navigation text or footer fragments as your snippet.',
        howToFix: 'Add a `<meta name="description" content="...">` tag in `<head>` (about 120–155 characters).',
        stepByStep: [
          'Write one clear sentence explaining what visitors can do on this page.',
          'Add `<meta name="description" content="Your summary here" />` inside `<head>`.',
          'Redeploy and re-scan.',
        ],
        howToVerify: 'Re-run LaunchGuard AI and confirm the Meta Description shows up in SEO Analysis.',
        codeSnippet: `<meta name="description" content="Describe what your app does and who it helps in 120-155 characters." />`,
      },
    });
  } else if (metaDescriptionLength < 50 || metaDescriptionLength > 170) {
    findings.push({
      id: 'seo-meta-desc',
      category: 'seo',
      title: 'Meta Description Length Could Be Improved',
      severity: 'low',
      status: 'warning',
      observedValue: `${metaDescriptionLength} chars`,
      expectedValue: '70–160 characters',
      explanation: 'Your meta description is either very brief or likely to get clipped in search snippets.',
      recommendation: 'Refine the description to roughly 120–155 characters.',
    });
  } else {
    findings.push({
      id: 'seo-meta-desc',
      category: 'seo',
      title: 'Meta Description Present',
      severity: 'pass',
      status: 'pass',
      observedValue: `${metaDescriptionLength} chars`,
      expectedValue: '50–170 characters',
      explanation: 'Your page has a well-sized meta description for search snippets.',
      recommendation: 'Keep it aligned with the visible page content.',
    });
  }

  // Viewport meta
  if (viewportMeta) {
    findings.push({
      id: 'seo-viewport',
      category: 'seo',
      title: 'Mobile Viewport Meta Configured',
      severity: 'pass',
      status: 'pass',
      observedValue: viewportMeta,
      expectedValue: 'width=device-width, initial-scale=1',
      explanation: 'Mobile browsers know how to scale your layout cleanly.',
      recommendation: 'No action needed.',
    });
  } else {
    findings.push({
      id: 'seo-viewport',
      category: 'seo',
      title: 'Missing Mobile Viewport Meta Tag',
      severity: 'medium',
      status: 'fail',
      observedValue: 'Missing',
      expectedValue: 'width=device-width, initial-scale=1.0',
      explanation: 'Without a viewport meta tag, phones render the page zoomed out like a desktop screen.',
      recommendation: 'Add <meta name="viewport" content="width=device-width, initial-scale=1.0" />.',
      fixGuide: {
        whatIsTheProblem: 'The `<meta name="viewport">` tag is missing from `<head>`.',
        whyItMatters: 'Mobile usability directly impacts both visitors and search rankings.',
        potentialRisk: 'Tiny unreadable text on phones and poor mobile search ranking.',
        howToFix: 'Insert the standard responsive viewport meta tag in your HTML head.',
        stepByStep: [
          'Open `index.html` or your main document layout.',
          'Add `<meta name="viewport" content="width=device-width, initial-scale=1.0" />` inside `<head>`.',
        ],
        howToVerify: 'Test on a phone or browser responsive mode, then re-scan.',
        codeSnippet: `<meta name="viewport" content="width=device-width, initial-scale=1.0" />`,
      },
    });
  }

  // H1 check
  if (h1Count === 0) {
    findings.push({
      id: 'seo-h1',
      category: 'seo',
      title: 'Missing Main Heading (<h1>)',
      severity: 'medium',
      status: 'warning',
      observedValue: '0 <h1> tags',
      expectedValue: '1 primary <h1> tag',
      explanation: 'No <h1> heading was found in the initial HTML.',
      recommendation: 'Include one clear <h1> heading that matches the page topic (note: client-rendered SPAs may populate H1 via JavaScript).',
    });
  } else if (h1Count > 1) {
    findings.push({
      id: 'seo-h1',
      category: 'seo',
      title: 'Multiple <h1> Headings Detected',
      severity: 'low',
      status: 'warning',
      observedValue: `${h1Count} <h1> tags`,
      expectedValue: '1 primary <h1> tag',
      explanation: 'Using a single <h1> helps screen readers and search engines identify the primary topic.',
      recommendation: 'Use one <h1> for the main page heading and <h2>/<h3> for sub-sections.',
    });
  } else {
    findings.push({
      id: 'seo-h1',
      category: 'seo',
      title: 'Single Primary <h1> Heading Found',
      severity: 'pass',
      status: 'pass',
      observedValue: h1Texts[0] || '1 <h1> tag',
      expectedValue: '1 primary <h1> tag',
      explanation: 'The page has a clear primary heading structure.',
      recommendation: 'Maintain clear heading hierarchy (h1 -> h2 -> h3).',
    });
  }

  // OpenGraph / Social sharing check
  if (!ogTitle || !ogDescription) {
    findings.push({
      id: 'seo-og',
      category: 'seo',
      title: 'Incomplete Social Sharing (OpenGraph) Tags',
      severity: 'low',
      status: 'warning',
      observedValue: `og:title=${ogTitle ? 'set' : 'missing'}, og:description=${ogDescription ? 'set' : 'missing'}`,
      expectedValue: 'og:title and og:description set',
      explanation: 'Links shared on Slack, LinkedIn, Discord, or X may lack a clean preview card.',
      recommendation: 'Add og:title, og:description, and og:image meta tags.',
    });
  } else {
    findings.push({
      id: 'seo-og',
      category: 'seo',
      title: 'OpenGraph Social Preview Tags Configured',
      severity: 'pass',
      status: 'pass',
      observedValue: 'og:title & og:description present',
      expectedValue: 'og:title & og:description',
      explanation: 'Shared links will render structured titles and descriptions on social platforms.',
      recommendation: 'Keep og:image updated when branding changes.',
    });
  }

  // Image alt attribute coverage
  if (totalImages > 0 && imagesMissingAlt > 0) {
    findings.push({
      id: 'seo-img-alt',
      category: 'seo',
      title: 'Images Missing Alt Text',
      severity: 'medium',
      status: 'warning',
      observedValue: `${imagesMissingAlt} of ${totalImages} images missing alt attribute`,
      expectedValue: 'All meaningful images have alt text',
      explanation: 'Images without alt attributes hurt screen-reader accessibility and image SEO.',
      recommendation: 'Add descriptive alt text to informational images (or alt="" for purely decorative images).',
    });
  }

  // HTML lang attribute
  if (!htmlLang) {
    findings.push({
      id: 'seo-lang',
      category: 'seo',
      title: 'Missing <html lang> Attribute',
      severity: 'low',
      status: 'warning',
      observedValue: 'Not set',
      expectedValue: 'e.g., lang="en"',
      explanation: 'Specifying the document language helps screen readers pronounce content accurately.',
      recommendation: 'Add lang="en" (or your primary language code) to the <html> tag.',
    });
  }

  return {
    title,
    titleLength,
    metaDescription,
    metaDescriptionLength,
    canonicalUrl,
    h1Count,
    h1Texts,
    htmlLang,
    viewportMeta,
    ogTitle,
    ogDescription,
    ogImage,
    robotsMeta,
    totalImages,
    imagesMissingAlt,
    findings,
  };
}

export async function runBrokenLinkCheck(
  finalUrl: string,
  $: cheerio.CheerioAPI,
  maxLinksToCheck: number,
  timeoutMs: number
): Promise<LinkCheckSummary> {
  const base = new URL(finalUrl);
  const allAnchors = $('a[href]');
  const totalExtractedLinks = allAnchors.length;

  const uniqueInternal = new Map<string, string>();

  allAnchors.each((_, el) => {
    const rawHref = ($(el).attr('href') || '').trim();
    if (
      !rawHref ||
      rawHref.startsWith('#') ||
      rawHref.startsWith('mailto:') ||
      rawHref.startsWith('tel:') ||
      rawHref.startsWith('javascript:')
    ) {
      return;
    }

    try {
      const resolved = new URL(rawHref, base);
      if (resolved.protocol !== 'http:' && resolved.protocol !== 'https:') return;
      if (resolved.origin !== base.origin) return;
      resolved.hash = '';
      const normalized = resolved.toString();
      if (normalized === finalUrl) return;
      if (!uniqueInternal.has(normalized)) {
        const text = $(el).text().replace(/\s+/g, ' ').trim().slice(0, 60) || resolved.pathname;
        uniqueInternal.set(normalized, text);
      }
    } catch {
      // skip invalid href
    }
  });

  const internalLinksFound = uniqueInternal.size;
  const limit = Math.min(20, Math.max(1, maxLinksToCheck));
  const toCheck = Array.from(uniqueInternal.entries()).slice(0, limit);
  const checkedLinks: CheckedLink[] = [];

  // Safe paced checking: 2 links per batch with 150ms interval between batches
  const batchSize = 2;
  const linkTimeout = Math.min(5000, timeoutMs);

  for (let i = 0; i < toCheck.length; i += batchSize) {
    const batch = toCheck.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(async ([url, anchorText]): Promise<CheckedLink> => {
        const started = Date.now();
        try {
          let res = await safeFetch(url, {
            method: 'HEAD',
            timeoutMs: linkTimeout,
            maxRedirects: 3,
          });
          // Some servers return 405 Method Not Allowed or 403 for HEAD — fallback to lightweight GET
          if (res.statusCode === 405 || res.statusCode === 403 || res.statusCode === 501) {
            res = await safeFetch(url, {
              method: 'GET',
              timeoutMs: linkTimeout,
              maxBytes: 32 * 1024,
              maxRedirects: 3,
            });
          }
          const ok = res.statusCode >= 200 && res.statusCode < 400;
          return {
            url,
            anchorText,
            statusCode: res.statusCode,
            ok,
            responseTimeMs: res.responseTimeMs,
            error: ok ? undefined : `HTTP ${res.statusCode} ${res.statusText || ''}`.trim(),
          };
        } catch (err) {
          return {
            url,
            anchorText,
            statusCode: null,
            ok: false,
            responseTimeMs: Date.now() - started,
            error: err instanceof Error ? err.message : 'Request failed',
          };
        }
      })
    );

    checkedLinks.push(...results);
    if (i + batchSize < toCheck.length) {
      await delay(150);
    }
  }

  const brokenLinks = checkedLinks.filter((l) => !l.ok);
  const healthyCount = checkedLinks.length - brokenLinks.length;
  const findings: AuditFinding[] = [];

  if (brokenLinks.length > 0) {
    findings.push({
      id: 'links-broken',
      category: 'links',
      title: `${brokenLinks.length} Broken Internal ${brokenLinks.length === 1 ? 'Link' : 'Links'} Detected`,
      severity: brokenLinks.length >= 3 ? 'high' : 'medium',
      status: 'fail',
      observedValue: `${brokenLinks.length} broken out of ${checkedLinks.length} checked`,
      expectedValue: '0 broken internal links',
      explanation: `Found internal links returning HTTP errors or failing to resolve (e.g., ${brokenLinks[0].url}).`,
      recommendation: 'Fix mistyped routes, restore missing pages, or set up redirects for moved URLs.',
      fixGuide: {
        whatIsTheProblem: `${brokenLinks.length} internal link(s) on your page returned HTTP errors (such as 404 Not Found).`,
        whyItMatters: 'Broken navigation links frustrate visitors and waste search engine crawl budget.',
        potentialRisk: 'Users hit dead ends during onboarding or checkout and abandon your site.',
        howToFix: 'Update each broken href to a valid route or add a 301 redirect.',
        stepByStep: [
          'Review each failed URL in the Broken Link Checker table below.',
          'Search your project code for the broken path string.',
          'Correct the route path or remove links to pages that are not built yet.',
        ],
        howToVerify: 'Click each updated link on your live site and re-run a LaunchGuard AI scan.',
      },
    });
  } else if (checkedLinks.length > 0) {
    findings.push({
      id: 'links-healthy',
      category: 'links',
      title: 'Checked Internal Links Healthy',
      severity: 'pass',
      status: 'pass',
      observedValue: `${healthyCount} of ${checkedLinks.length} returned 2xx/3xx`,
      expectedValue: 'All checked links reachable',
      explanation: 'Every sampled internal link responded cleanly without HTTP errors.',
      recommendation: 'Re-check links whenever renaming routes or removing pages.',
    });
  }

  return {
    totalExtractedLinks,
    internalLinksFound,
    checkedCount: checkedLinks.length,
    maxCheckedLimit: limit,
    brokenCount: brokenLinks.length,
    healthyCount,
    links: checkedLinks,
    findings,
  };
}

export function calculateReadinessScore(
  availability: AvailabilityResult,
  security: SecurityResult,
  performance: PerformanceResult,
  seo: SeoResult,
  links: LinkCheckSummary
): { score: ReadinessScore; allFindings: AuditFinding[] } {
  const deductions: ScoreDeduction[] = [];

  // 1. Availability Score (100 base)
  let availabilityScore = 100;
  if (!availability.reachable || availability.statusCode >= 500) {
    availabilityScore = 0;
    deductions.push({
      category: 'availability',
      reason: `Server returned HTTP ${availability.statusCode}`,
      points: 100,
    });
  } else if (availability.statusCode >= 400) {
    availabilityScore = 30;
    deductions.push({
      category: 'availability',
      reason: `Client error HTTP ${availability.statusCode}`,
      points: 70,
    });
  } else {
    if (availability.redirectChain.length > 2) {
      availabilityScore -= 10;
      deductions.push({
        category: 'availability',
        reason: `Long redirect chain (${availability.redirectChain.length} hops)`,
        points: 10,
      });
    }
    if (links.brokenCount > 0) {
      const penalty = Math.min(35, links.brokenCount * 12);
      availabilityScore -= penalty;
      deductions.push({
        category: 'availability',
        reason: `${links.brokenCount} broken internal link(s)`,
        points: penalty,
      });
    }
  }
  availabilityScore = Math.max(0, Math.min(100, availabilityScore));

  // 2. Security Score (100 base)
  let securityScore = 100;
  const secPenaltyMap: Record<string, number> = {
    'sec-https': 35,
    'sec-tls-cert': 25,
    'sec-csp': 15,
    'sec-xfo': 10,
    'sec-xcto': 8,
    'sec-hsts': 10,
    'sec-server-exposure': 5,
  };
  for (const f of security.findings) {
    if (f.status === 'fail' || f.status === 'warning') {
      const basePts = secPenaltyMap[f.id] ?? 8;
      const pts = f.status === 'warning' && f.id === 'sec-tls-cert' ? 12 : basePts;
      securityScore -= pts;
      deductions.push({
        category: 'security',
        reason: f.title,
        points: pts,
      });
    }
  }
  securityScore = Math.max(0, Math.min(100, securityScore));

  // 3. Performance Score (100 base)
  let performanceScore = 100;
  for (const f of performance.findings) {
    if (f.status === 'fail') {
      const pts = f.id === 'perf-ttfb' ? 30 : 20;
      performanceScore -= pts;
      deductions.push({ category: 'performance', reason: f.title, points: pts });
    } else if (f.status === 'warning') {
      const pts = f.id === 'perf-ttfb' ? 15 : 10;
      performanceScore -= pts;
      deductions.push({ category: 'performance', reason: f.title, points: pts });
    }
  }
  performanceScore = Math.max(0, Math.min(100, performanceScore));

  // 4. SEO Score (100 base)
  let seoScore = 100;
  const seoPenaltyMap: Record<string, number> = {
    'seo-title': 25,
    'seo-meta-desc': 20,
    'seo-viewport': 20,
    'seo-h1': 12,
    'seo-og': 8,
    'seo-img-alt': 10,
    'seo-lang': 5,
  };
  for (const f of seo.findings) {
    if (f.status === 'fail' || f.status === 'warning') {
      const basePts = seoPenaltyMap[f.id] ?? 8;
      const pts = f.status === 'warning' && f.id === 'seo-title' ? 10 : basePts;
      seoScore -= pts;
      deductions.push({ category: 'seo', reason: f.title, points: pts });
    }
  }
  seoScore = Math.max(0, Math.min(100, seoScore));

  const weights = {
    security: 0.35,
    performance: 0.25,
    seo: 0.2,
    availability: 0.2,
  };

  const overall = Math.round(
    securityScore * weights.security +
      performanceScore * weights.performance +
      seoScore * weights.seo +
      availabilityScore * weights.availability
  );

  const availabilityFindings: AuditFinding[] = [];
  if (availability.statusCode >= 200 && availability.statusCode < 400) {
    availabilityFindings.push({
      id: 'avail-http-status',
      category: 'availability',
      title: `Website Reachable (HTTP ${availability.statusCode})`,
      severity: 'pass',
      status: 'pass',
      observedValue: `HTTP ${availability.statusCode} in ${availability.responseTimeMs}ms`,
      expectedValue: 'HTTP 200',
      explanation: 'The public URL responded successfully to our request.',
      recommendation: 'Set up periodic uptime checks after launch.',
    });
  } else {
    availabilityFindings.push({
      id: 'avail-http-status',
      category: 'availability',
      title: `Unexpected HTTP Status (${availability.statusCode})`,
      severity: 'critical',
      status: 'fail',
      observedValue: `HTTP ${availability.statusCode} ${availability.statusText}`,
      expectedValue: 'HTTP 200',
      explanation: 'The target URL returned an error status code instead of a healthy page.',
      recommendation: 'Inspect server error logs and deployment status before launching.',
    });
  }

  if (availability.redirectChain.length > 0) {
    availabilityFindings.push({
      id: 'avail-redirects',
      category: 'availability',
      title:
        availability.redirectChain.length > 2
          ? 'Excessive Redirect Chain'
          : 'Redirects Detected',
      severity: availability.redirectChain.length > 2 ? 'medium' : 'info',
      status: availability.redirectChain.length > 2 ? 'warning' : 'pass',
      observedValue: `${availability.redirectChain.length} redirect hop(s) -> ${availability.finalUrl}`,
      expectedValue: '0–1 redirect hops',
      explanation: 'The requested URL redirected to its canonical destination.',
      recommendation:
        availability.redirectChain.length > 2
          ? 'Collapse multiple redirects into a single direct 301 redirect.'
          : 'Redirect chain is clean.',
    });
  }

  const allFindings: AuditFinding[] = [
    ...availabilityFindings,
    ...security.findings,
    ...performance.findings,
    ...seo.findings,
    ...links.findings,
  ];

  const passed = allFindings.filter((f) => f.status === 'pass').length;
  const warnings = allFindings.filter((f) => f.status === 'warning').length;
  const failed = allFindings.filter((f) => f.status === 'fail').length;

  const grade: ReadinessScore['grade'] =
    overall >= 80 && failed === 0
      ? 'Launch Ready'
      : overall >= 60
        ? 'Needs Attention'
        : 'Action Required';

  return {
    score: {
      overall,
      grade,
      weights,
      categories: {
        security: securityScore,
        performance: performanceScore,
        seo: seoScore,
        availability: availabilityScore,
      },
      counts: {
        passed,
        warnings,
        failed,
      },
      deductions,
    },
    allFindings,
  };
}

export function parseHtmlDocument(html: string): cheerio.CheerioAPI {
  return cheerio.load(html);
}
