import tls from 'tls';
import type { TlsCertificateInfo } from '../../src/types/scan.ts';
import type { ValidatedTarget } from '../security/ssrf.ts';

export function inspectTlsCertificate(
  target: ValidatedTarget,
  timeoutMs = 7000
): Promise<TlsCertificateInfo> {
  return new Promise((resolve) => {
    if (target.url.protocol !== 'https:') {
      resolve({
        available: false,
        valid: false,
        error: 'Target is served over plain HTTP without TLS encryption.',
      });
      return;
    }

    const port = target.url.port ? Number(target.url.port) : 443;
    let settled = false;

    const finish = (info: TlsCertificateInfo) => {
      if (settled) return;
      settled = true;
      resolve(info);
    };

    const socket = tls.connect(
      {
        host: target.resolvedIp,
        port,
        servername: target.url.hostname,
        rejectUnauthorized: false,
        timeout: timeoutMs,
      },
      () => {
        try {
          const cert = socket.getPeerCertificate();
          const protocol = socket.getProtocol() ?? undefined;
          const cipher = socket.getCipher()?.name;
          const authorized = socket.authorized;
          const authError = socket.authorizationError
            ? String(socket.authorizationError)
            : undefined;

          if (!cert || Object.keys(cert).length === 0) {
            socket.end();
            finish({
              available: false,
              valid: false,
              error: 'No peer TLS certificate was presented by the server.',
            });
            return;
          }

          const validFromDate = cert.valid_from ? new Date(cert.valid_from) : null;
          const validToDate = cert.valid_to ? new Date(cert.valid_to) : null;
          const now = Date.now();
          const daysRemaining = validToDate
            ? Math.floor((validToDate.getTime() - now) / (1000 * 60 * 60 * 24))
            : undefined;

          const notExpired =
            validToDate !== null &&
            validFromDate !== null &&
            now >= validFromDate.getTime() &&
            now <= validToDate.getTime();

          const subject =
            typeof cert.subject?.CN === 'string'
              ? cert.subject.CN
              : Array.isArray(cert.subject?.CN)
                ? cert.subject.CN.join(', ')
                : target.url.hostname;

          const issuerParts = [cert.issuer?.O, cert.issuer?.CN].filter(Boolean);
          const issuer = issuerParts.length > 0 ? issuerParts.join(' — ') : 'Unknown Issuer';

          socket.end();
          finish({
            available: true,
            valid: Boolean(authorized && notExpired),
            authorizationError: authorized ? undefined : authError,
            subject,
            issuer,
            validFrom: validFromDate ? validFromDate.toISOString() : undefined,
            validTo: validToDate ? validToDate.toISOString() : undefined,
            daysRemaining,
            protocol,
            cipher,
          });
        } catch (err) {
          socket.destroy();
          finish({
            available: false,
            valid: false,
            error: err instanceof Error ? err.message : 'TLS inspection failed.',
          });
        }
      }
    );

    socket.setTimeout(timeoutMs, () => {
      socket.destroy();
      finish({
        available: false,
        valid: false,
        error: `TLS handshake timed out after ${timeoutMs}ms.`,
      });
    });

    socket.on('error', (err) => {
      finish({
        available: false,
        valid: false,
        error: err.message || 'TLS connection failed.',
      });
    });
  });
}
