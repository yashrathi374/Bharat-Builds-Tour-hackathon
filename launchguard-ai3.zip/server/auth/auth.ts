import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import {
  claimGuestScansForUser,
  createSession,
  createUser,
  deleteSession,
  findUserByEmail,
  getUserBySessionToken,
} from '../db/database.ts';
import type { AuthUser } from '../../src/types/scan.ts';

const SESSION_COOKIE = 'lg_session';
const WORKSPACE_COOKIE = 'lg_workspace';

export interface AuthenticatedRequest extends Request {
  authUser?: AuthUser;
  ownerKey: string;
  guestWorkspaceId: string;
}

declare global {
  namespace Express {
    interface Request {
      authUser?: AuthUser;
      ownerKey: string;
      guestWorkspaceId: string;
    }
  }
}

export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  const computed = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(storedHash, 'hex');
  if (computed.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(computed, storedBuf);
}

function cookieOptions(maxAgeMs: number) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: maxAgeMs,
  };
}

export function attachAuth(req: Request, res: Response, next: NextFunction): void {
  const authReq = req as AuthenticatedRequest;
  let guestId = req.cookies?.[WORKSPACE_COOKIE] as string | undefined;

  if (!guestId || !/^[a-f0-9-]{16,64}$/i.test(guestId)) {
    guestId = crypto.randomUUID();
    res.cookie(WORKSPACE_COOKIE, guestId, cookieOptions(1000 * 60 * 60 * 24 * 90));
  }

  authReq.guestWorkspaceId = guestId;

  const sessionToken = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (sessionToken) {
    const user = getUserBySessionToken(sessionToken);
    if (user) {
      authReq.authUser = user;
      authReq.ownerKey = `user:${user.id}`;
      next();
      return;
    }
  }

  authReq.ownerKey = `guest:${guestId}`;
  next();
}

export function registerAccount(
  req: AuthenticatedRequest,
  res: Response
): void {
  const { email, password, name } = req.body as {
    email?: string;
    password?: string;
    name?: string;
  };

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    res.status(400).json({ error: 'Enter a valid email address.' });
    return;
  }
  if (!name || name.trim().length < 2 || name.trim().length > 80) {
    res.status(400).json({ error: 'Enter a display name between 2 and 80 characters.' });
    return;
  }
  if (!password || password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    return;
  }

  const existing = findUserByEmail(email);
  if (existing) {
    res.status(409).json({ error: 'An account with that email already exists.' });
    return;
  }

  const { hash, salt } = hashPassword(password);
  const userId = crypto.randomUUID();
  const user = createUser(userId, email, name, hash, salt);

  // Preserve any scans created in the current browser session
  claimGuestScansForUser(`guest:${req.guestWorkspaceId}`, user.id);

  const token = crypto.randomBytes(32).toString('hex');
  createSession(token, user.id);
  res.cookie(SESSION_COOKIE, token, cookieOptions(1000 * 60 * 60 * 24 * 14));
  res.status(201).json({ user });
}

export function loginAccount(
  req: AuthenticatedRequest,
  res: Response
): void {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required.' });
    return;
  }

  const row = findUserByEmail(email);
  if (!row || !verifyPassword(password, row.password_hash, row.password_salt)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const token = crypto.randomBytes(32).toString('hex');
  createSession(token, row.id);
  res.cookie(SESSION_COOKIE, token, cookieOptions(1000 * 60 * 60 * 24 * 14));
  res.json({
    user: {
      id: row.id,
      email: row.email,
      name: row.name,
      createdAt: row.created_at,
    },
  });
}

export function logoutAccount(req: AuthenticatedRequest, res: Response): void {
  const sessionToken = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (sessionToken) {
    deleteSession(sessionToken);
  }
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.json({ ok: true });
}
